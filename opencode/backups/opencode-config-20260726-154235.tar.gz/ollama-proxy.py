#!/usr/bin/env python3
"""Proxy ligero: OpenCode -> Ollama con num_ctx y num_predict forzados."""
import json, http.server, urllib.request, sys

OLLAMA_BASE = "http://localhost:11434"
NUM_CTX = 32768
NUM_PREDICT = 16384


class Proxy(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"

    def _json(self, data, code=200):
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode())

    def do_GET(self):
        if self.path in ("/v1/models", "/models"):
            req = urllib.request.Request(f"{OLLAMA_BASE}/api/tags")
            with urllib.request.urlopen(req) as r:
                data = json.load(r)
            models = {"object": "list", "data": []}
            for m in data.get("models", []):
                models["data"].append({"id": m["name"], "object": "model"})
            self._json(models)
        else:
            self._json({"error": "not found"}, 404)

    def do_POST(self):
        if "/chat/completions" not in self.path:
            return self._json({"error": "not found"}, 404)

        raw = self.rfile.read(int(self.headers.get("Content-Length", 0)))
        body = json.loads(raw)
        model = body.get("model", "")
        stream = body.get("stream", False)
        messages = body.get("messages", [])

        # Construir body para Ollama
        ollama_body = {
            "model": model,
            "stream": stream,
            "messages": messages,
            "options": {
                "num_ctx": NUM_CTX,
                "num_predict": NUM_PREDICT,
            },
        }
        # Pasar max_tokens si existe
        if "max_tokens" in body:
            ollama_body["options"]["num_predict"] = body["max_tokens"]
        # Pasar tools si existen
        if "tools" in body:
            ollama_body["tools"] = body["tools"]

        if stream:
            self._handle_stream(ollama_body, model)
        else:
            self._handle_single(ollama_body, model)

    def _call_ollama(self, ollama_body):
        """Llama a Ollama y devuelve la respuesta."""
        req_body = json.dumps(ollama_body, ensure_ascii=False)
        req = urllib.request.Request(
            f"{OLLAMA_BASE}/api/chat",
            data=req_body.encode(),
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=600) as r:
            return json.load(r)

    def _handle_single(self, ollama_body, model):
        try:
            result = self._call_ollama(ollama_body)
        except Exception as e:
            return self._json({"error": str(e)}, 500)

        msg = result.get("message", {})
        content = msg.get("content") or ""
        thinking = msg.get("thinking") or ""
        tc = msg.get("tool_calls")

        # Si el modelo solo ha pensado pero no ha generado respuesta,
        # usar el thinking como contenido (modelos de razonamiento)
        if not content and thinking:
            content = thinking

        choice = {
            "index": 0,
            "message": {"role": "assistant", "content": content},
            "finish_reason": "tool_calls" if tc else "stop",
        }
        if tc:
            choice["message"]["tool_calls"] = [
                {
                    "id": t.get("id", "call_1"),
                    "type": "function",
                    "function": {
                        "name": t["function"]["name"],
                        "arguments": json.dumps(t["function"]["arguments"]),
                    },
                }
                for t in tc
            ]

        self._json({
            "id": "chatcmpl-1",
            "object": "chat.completion",
            "choices": [choice],
            "model": model,
        })

    def _handle_stream(self, ollama_body, model):
        """Streaming real: reenvia los SSE de Ollama al cliente."""
        self.close_connection = True
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.flush()

        req_body = json.dumps(ollama_body, ensure_ascii=False)
        req = urllib.request.Request(
            f"{OLLAMA_BASE}/api/chat",
            data=req_body.encode(),
            headers={"Content-Type": "application/json"},
        )

        try:
            with urllib.request.urlopen(req, timeout=600) as r:
                buffer = ""
                while True:
                    chunk = r.read(4096)
                    if not chunk:
                        break
                    buffer += chunk.decode("utf-8", errors="replace")
                    while "\n" in buffer:
                        line, buffer = buffer.split("\n", 1)
                        line = line.strip()
                        if not line:
                            continue
                        if line == "data: [DONE]":
                            self.wfile.write(b"data: [DONE]\n\n")
                            self.wfile.flush()
                            return
                        # Ollama: raw JSON line; OpenAI: "data: {...}"
                        raw = line[6:] if line.startswith("data: ") else line
                        try:
                            data = json.loads(raw)
                        except json.JSONDecodeError:
                            continue
                        msg = data.get("message", {})
                        content = msg.get("content", "")
                        thinking = msg.get("thinking", "")
                        done = data.get("done", False)

                        # Modelos de razonamiento: usar thinking como content si no hay
                        if not content and thinking:
                            content = thinking

                        delta = {}
                        if content:
                            delta["content"] = content
                        tc = msg.get("tool_calls")
                        if tc:
                            delta["tool_calls"] = [
                                {
                                    "id": t.get("id", "call_1"),
                                    "type": "function",
                                    "function": {
                                        "name": t["function"]["name"],
                                        "arguments": json.dumps(t["function"]["arguments"]),
                                    },
                                }
                                for t in tc
                            ]

                        # No enviar chunks vacios (solo si hay delta o done)
                        if not delta and not done:
                            continue

                        chunk_data = {
                            "id": "chatcmpl-1",
                            "object": "chat.completion.chunk",
                            "choices": [{
                                "index": 0,
                                "delta": delta,
                                "finish_reason": "stop" if done else None,
                            }],
                            "model": model,
                        }
                        sse = f"data: {json.dumps(chunk_data, ensure_ascii=False)}\n\n"
                        self.wfile.write(sse.encode())
                        self.wfile.flush()

                        if done:
                            self.wfile.write(b"data: [DONE]\n\n")
                            self.wfile.flush()
                            return
        except Exception as e:
            print(f"[proxy] Error streaming: {e}", flush=True, file=sys.stderr)
            try:
                err = {
                    "id": "chatcmpl-1",
                    "object": "chat.completion.chunk",
                    "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
                    "model": model,
                }
                self.wfile.write(f"data: {json.dumps(err, ensure_ascii=False)}\n\n".encode())
                self.wfile.write(b"data: [DONE]\n\n")
                self.wfile.flush()
            except Exception:
                pass

        try:
            self.connection.shutdown(__import__("socket").SHUT_WR)
        except Exception:
            pass


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 4000
    server = http.server.ThreadingHTTPServer(("127.0.0.1", port), Proxy)
    print(f"Proxy en http://127.0.0.1:{port}", flush=True)
    server.serve_forever()
