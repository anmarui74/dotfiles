#!/usr/bin/env python3
"""Proxy OpenCode ↔ Ollama: no-streaming interno, inyección de tools MCP."""
import json, http.server, urllib.request, sys, time, uuid, threading, subprocess, re, os

OLLAMA_BASE = "http://localhost:11434"
NUM_CTX_DEFAULT = 16384
NUM_PREDICT_DEFAULT = 8192
VRAM_THRESHOLD = 75
CHECK_INTERVAL = 2

CONFIG_DIR = os.path.dirname(os.path.abspath(__file__))
MCP_CACHE_PATH = os.path.join(CONFIG_DIR, "data", "mcp_tools_cache.json")

# Caché global de herramientas MCP (formato OpenAI)
_mcp_tools_cache: list[dict] = []
_mcp_tools_lock = threading.Lock()
_mcp_tools_ready = threading.Event()

# Contador de respuestas por modelo
_resp_counter: dict[str, int] = {}
_counter_lock = threading.Lock()


# ── Carga de herramientas MCP ──────────────────────────────────────────────

def _load_tools_from_cache() -> list[dict]:
    """Carga las tools desde el archivo de caché si existe."""
    if os.path.exists(MCP_CACHE_PATH):
        try:
            with open(MCP_CACHE_PATH) as f:
                return json.load(f)
        except Exception as e:
            print(f"[proxy] Error leyendo caché MCP: {e}", flush=True)
    return []


def _regenerate_cache() -> list[dict]:
    """Regenera la caché ejecutando los MCP servers y extrayendo sus tools."""
    all_tools: list[dict] = []

    # Servidores MCP: (id, [comando, args...])
    servers = [
        ("filesystem", [
            "node",
            os.path.expanduser(
                "~/.npm/_npx/a3241bba59c344f5/node_modules/"
                ".bin/mcp-server-filesystem"
            ),
            os.path.expanduser("~"),
        ]),
        ("fetch", ["mcp-fetch-server"]),
    ]

    for server_id, cmd in servers:
        try:
            if not os.path.exists(cmd[1]) if len(cmd) > 1 else True:
                # Fallback a npx si no existe la ruta directa
                alt_cmd = ["npx", "-y"]
                if server_id == "filesystem":
                    alt_cmd.extend([
                        "@modelcontextprotocol/server-filesystem",
                        os.path.expanduser("~"),
                    ])
                else:
                    alt_cmd.append("mcp-fetch-server")
                cmd = alt_cmd

            proc = subprocess.Popen(
                cmd, stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True,
            )
            req = json.dumps({"jsonrpc": "2.0", "id": 1, "method": "tools/list"})
            stdout, stderr = proc.communicate(input=req, timeout=20)

            if stdout:
                result = json.loads(stdout)
                for tool in result.get("result", {}).get("tools", []):
                    all_tools.append({
                        "type": "function",
                        "function": {
                            "name": f"{server_id}__{tool['name']}",
                            "description": tool.get("description", ""),
                            "parameters": tool.get("inputSchema", {
                                "type": "object", "properties": {}
                            }),
                        }
                    })
                print(f"[proxy] MCP {server_id}: {len(result.get('result', {}).get('tools', []))} tools",
                      flush=True)
        except Exception as e:
            print(f"[proxy] MCP {server_id}: error -> {e}", flush=True)

    # Guardar en caché
    if all_tools:
        os.makedirs(os.path.dirname(MCP_CACHE_PATH), exist_ok=True)
        with open(MCP_CACHE_PATH, "w") as f:
            json.dump(all_tools, f, ensure_ascii=False, indent=2)
        print(f"[proxy] Caché MCP guardada: {len(all_tools)} tools", flush=True)

    return all_tools


def _init_mcp_tools() -> None:
    """Inicializa la caché: primero intenta cargar, luego regenera en bg."""
    cached = _load_tools_from_cache()
    if cached:
        with _mcp_tools_lock:
            _mcp_tools_cache.extend(cached)
        _mcp_tools_ready.set()
        print(f"[proxy] Tools MCP cargadas de caché: {len(cached)}", flush=True)
        # Regenerar en segundo plano para mantener actualizado
        t = threading.Thread(target=_refresh_cache_bg, daemon=True)
        t.start()
    else:
        # Sin caché: regenerar ahora (puede tardar)
        fresh = _regenerate_cache()
        if fresh:
            with _mcp_tools_lock:
                _mcp_tools_cache.extend(fresh)
        _mcp_tools_ready.set()
        print(f"[proxy] Tools MCP generadas: {len(fresh)}", flush=True)


def _refresh_cache_bg() -> None:
    """Regenera la caché en segundo plano sin bloquear."""
    fresh = _regenerate_cache()
    if fresh:
        with _mcp_tools_lock:
            _mcp_tools_cache.clear()
            _mcp_tools_cache.extend(fresh)


def _get_mcp_tools() -> list[dict]:
    """Devuelve la caché de herramientas MCP (hilo seguro)."""
    _mcp_tools_ready.wait(timeout=60)
    with _mcp_tools_lock:
        return list(_mcp_tools_cache)


# ── Gestión de VRAM ────────────────────────────────────────────────────────

def _get_vram_usage() -> float:
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=memory.used,memory.total",
             "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode != 0:
            return 0.0
        line = result.stdout.strip()
        if not line:
            return 0.0
        parts = line.split(",")
        if len(parts) >= 2:
            used = float(parts[0].strip())
            total = float(parts[1].strip())
            if total > 0:
                return (used / total) * 100.0
    except Exception:
        pass
    return 0.0


def _cleanup_model(model: str) -> None:
    try:
        req = urllib.request.Request(
            f"{OLLAMA_BASE}/api/generate",
            data=json.dumps({"model": model, "prompt": "", "keep_alive": 0}).encode(),
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=10) as _:
            pass
        print(f"[proxy] KV cache liberada para {model}", flush=True)
    except Exception:
        pass


def _check_vram_and_clean(model: str) -> None:
    vram_pct = _get_vram_usage()
    if vram_pct <= 0:
        return
    if vram_pct >= VRAM_THRESHOLD:
        print(f"[proxy] VRAM al {vram_pct:.0f}% — limpiando cache de {model}", flush=True)
        _cleanup_model(model)
    else:
        print(f"[proxy] VRAM al {vram_pct:.0f}% — OK", flush=True)


# ── Normalización de mensajes ──────────────────────────────────────────────

def _normalize_messages(messages: list[dict]) -> None:
    for m in messages:
        c = m.get("content")
        if isinstance(c, list):
            texts: list[str] = []
            for part in c:
                if isinstance(part, dict):
                    t = part.get("type")
                    if t == "text":
                        texts.append(part.get("text", ""))
                    elif t == "tool_result":
                        texts.append(str(part.get("content", "")))
                    else:
                        texts.append(str(part.get("text", "") or ""))
                else:
                    texts.append(str(part))
            m["content"] = "\n".join(texts) if texts else ""

        tc = m.get("tool_calls")
        if tc:
            for t in tc:
                func = t.get("function", {})
                args = func.get("arguments")
                if isinstance(args, str):
                    try:
                        func["arguments"] = json.loads(args)
                    except json.JSONDecodeError:
                        pass


# ── Proxy HTTP ─────────────────────────────────────────────────────────────

class Proxy(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"

    def _json(self, data: object, code: int = 200) -> None:
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode())

    def _sse(self, data: dict) -> None:
        self.wfile.write(f"data: {json.dumps(data, ensure_ascii=False)}\n\n".encode())
        self.wfile.flush()

    def do_GET(self) -> None:
        if self.path in ("/v1/models", "/models"):
            req = urllib.request.Request(f"{OLLAMA_BASE}/api/tags")
            with urllib.request.urlopen(req) as r:
                data = json.load(r)
            models: dict = {"object": "list", "data": []}
            for m in data.get("models", []):
                models["data"].append({"id": m["name"], "object": "model"})
            self._json(models)
        else:
            self._json({"error": "not found"}, 404)

    def do_POST(self) -> None:
        path = self.path
        # Si es /v1/responses, lo tratamos como chat completions
        if "/v1/responses" in path:
            path = "/v1/chat/completions"
        if "/chat/completions" not in path:
            return self._json({"error": "not found"}, 404)
        self._handle_chat_completion()

    def _handle_chat_completion(self) -> None:

        raw = self.rfile.read(int(self.headers.get("Content-Length", 0)))
        body = json.loads(raw)
        model: str = body.get("model", "")
        want_stream: bool = body.get("stream", False)
        messages: list[dict] = body.get("messages", [])

        # ── WORKAROUND: Inyectar herramientas MCP si OpenCode no las manda ──
        # Bug de OpenCode: envía "tools": [] en vez de las definiciones reales
        raw_tools = body.get("tools")
        has_empty_tools = isinstance(raw_tools, list) and len(raw_tools) == 0
        has_no_tools = "tools" not in body

        if has_empty_tools or has_no_tools:
            mcp_tools = _get_mcp_tools()
            if mcp_tools:
                body["tools"] = mcp_tools
                if has_empty_tools:
                    print(f"[proxy] ⚡ WORKAROUND: inyectadas {len(mcp_tools)} tools MCP "
                          f"(OpenCode las envió vacías)", flush=True)
                else:
                    print(f"[proxy] ⚡ WORKAROUND: inyectadas {len(mcp_tools)} tools MCP "
                          f"(OpenCode no envió tools)", flush=True)

        _normalize_messages(messages)

        opencode_ctx = body.get("options", {}).get("num_ctx")
        ctx = opencode_ctx if opencode_ctx else NUM_CTX_DEFAULT
        np = min(body.get("max_tokens", NUM_PREDICT_DEFAULT), 8192)

        ollama_body: dict = {
            "model": model,
            "stream": False,
            "messages": messages,
            "keep_alive": "10m",
            "options": {"num_ctx": ctx, "num_predict": np},
        }

        final_tools = body.get("tools")
        if final_tools and isinstance(final_tools, list) and len(final_tools) > 0:
            ollama_body["tools"] = final_tools
            ollama_body["reasoning_effort"] = "none"

        print(
            f"[proxy] model={model} tools={'yes' if ollama_body.get('tools') else 'no'} "
            f"stream={want_stream} msgs={len(messages)} ctx={ctx} np={np}",
            flush=True,
        )

        try:
            req_body_str: str = json.dumps(ollama_body, ensure_ascii=False)
            req = urllib.request.Request(
                f"{OLLAMA_BASE}/api/chat",
                data=req_body_str.encode(),
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=600) as r:
                result: dict = json.load(r)
        except urllib.error.HTTPError as e:
            err_text: str = e.read().decode("utf-8", errors="replace")[:500]
            print(f"[proxy] HTTP {e.code}: {err_text}", flush=True, file=sys.stderr)
            fname: str = f"/tmp/proxy-error-{uuid.uuid4().hex[:8]}.json"
            with open(fname, "w") as f:
                f.write(req_body_str)
            print(f"[proxy] Body guardado en {fname}", flush=True, file=sys.stderr)
            return self._json({"error": f"HTTP {e.code}: {err_text}"}, 502)
        except Exception as e:
            print(f"[proxy] Error: {e}", flush=True, file=sys.stderr)
            return self._json({"error": str(e)}, 500)

        msg: dict = result.get("message", {})
        content: str = msg.get("content") or ""
        thinking: str = msg.get("thinking") or ""
        tc = msg.get("tool_calls")

        if not content and not tc and thinking:
            content = thinking

        tool_calls = None
        if tc:
            tool_calls = [
                {
                    "id": t.get("id", f"call_{i}"),
                    "type": "function",
                    "function": {
                        "name": t["function"]["name"],
                        "arguments": json.dumps(t["function"]["arguments"]),
                    },
                }
                for i, t in enumerate(tc)
            ]

        _check_vram_and_clean(model)
        _check_cleanup(model)

        if want_stream:
            self._send_stream(model, content, tool_calls)
        else:
            self._send_single(model, content, tool_calls)

    def _send_single(self, model: str, content: str, tool_calls: list | None) -> None:
        choice: dict = {
            "index": 0,
            "message": {"role": "assistant", "content": content},
            "finish_reason": "tool_calls" if tool_calls else "stop",
        }
        if tool_calls:
            choice["message"]["tool_calls"] = tool_calls
        self._json({
            "id": "chatcmpl-1",
            "object": "chat.completion",
            "choices": [choice],
            "model": model,
        })

    def _send_stream(self, model: str, content: str, tool_calls: list | None) -> None:
        self.close_connection = True
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.flush()

        try:
            if tool_calls:
                delta: dict = {"role": "assistant", "tool_calls": tool_calls}
                chunk: dict = {
                    "id": "chatcmpl-1",
                    "object": "chat.completion.chunk",
                    "choices": [
                        {"index": 0, "delta": delta, "finish_reason": "tool_calls"}
                    ],
                    "model": model,
                }
                self._sse(chunk)
            else:
                content = content or ""
                chunk_size: int = 20
                for i in range(0, len(content), chunk_size):
                    delta = {"content": content[i: i + chunk_size]}
                    chunk = {
                        "id": "chatcmpl-1",
                        "object": "chat.completion.chunk",
                        "choices": [
                            {"index": 0, "delta": delta, "finish_reason": None}
                        ],
                        "model": model,
                    }
                    self._sse(chunk)
                    time.sleep(0.005)
                chunk = {
                    "id": "chatcmpl-1",
                    "object": "chat.completion.chunk",
                    "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
                    "model": model,
                }
                self._sse(chunk)
        except Exception:
            pass

        try:
            self.wfile.write(b"data: [DONE]\n\n")
            self.wfile.flush()
        except Exception:
            pass

        try:
            self.connection.shutdown(__import__("socket").SHUT_WR)
        except Exception:
            pass


def _check_cleanup(model: str) -> None:
    with _counter_lock:
        _resp_counter[model] = _resp_counter.get(model, 0) + 1
        count: int = _resp_counter[model]
        if count >= CHECK_INTERVAL:
            _resp_counter[model] = 0
            t = threading.Thread(
                target=_check_vram_and_clean, args=(model,), daemon=True
            )
            t.start()


if __name__ == "__main__":
    port: int = int(sys.argv[1]) if len(sys.argv) > 1 else 4000

    # Inicializar tools MCP
    _init_mcp_tools()

    server = http.server.ThreadingHTTPServer(("127.0.0.1", port), Proxy)
    print(f"Proxy en http://127.0.0.1:{port}", flush=True)
    print(f"VRAM threshold: {VRAM_THRESHOLD}%, "
          f"check each {CHECK_INTERVAL} respuestas, "
          f"num_ctx_default={NUM_CTX_DEFAULT}", flush=True)
    print(f"MCP tools cache: {MCP_CACHE_PATH}", flush=True)
    server.serve_forever()
