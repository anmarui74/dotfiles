#!/usr/bin/env bash
# setup-ollama-models.sh — Descarga/verifica modelos base para Ollama
# Uso: bash setup-ollama-models.sh
# Los parámetros num_ctx y maxTokens los gestiona OpenCode + proxy.

set -euo pipefail

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

info()  { echo -e "${GREEN}[✓]${NC} $1"; }
warn()  { echo -e "${YELLOW}[!]${NC} $1"; }
err()   { echo -e "${RED}[✗]${NC} $1"; }

echo "=============================================="
echo "  Verificación de modelos Ollama para OpenCode"
echo "=============================================="
echo ""

# Modelos base (sin sufijos: num_ctx y maxTokens los gestiona OpenCode + proxy)
MODELS=(
    "qwen3.5:9b-stock"
    "llama3.1:8b"
    "gemma4:e4b"
    "deepseek-r1:8b"
    "deepseek-v4-flash-stock:latest"
)

# Verificar que Ollama está corriendo
if ! pgrep -x "ollama" > /dev/null; then
    err "Ollama no está corriendo. Inícialo con: ollama serve"
    exit 1
fi

info "Ollama está corriendo"

# Procesar cada modelo
for model in "${MODELS[@]}"; do
    echo ""
    echo "--- Verificando: $model ---"
    
    if ollama list | grep -q "^${model}[[:space:]]"; then
        info "Modelo $model ya disponible"
    else
        warn "Descargando $model (esto puede tardar varios minutos)..."
        if ollama pull "$model"; then
            info "Modelo $model descargado correctamente"
        else
            err "Error al descargar $model"
        fi
    fi
    
    # Verificar tool calling
    capabilities=$(ollama show "$model" 2>/dev/null | grep -A 10 "Capabilities" | grep -i "tools" || true)
    if [ -n "$capabilities" ]; then
        info "Modelo $model soporta tool calling ✓"
    else
        warn "Modelo $model NO soporta tool calling"
    fi
done

echo ""
echo "=============================================="
echo "  Verificación completada"
echo "=============================================="
echo ""
echo "Modelos disponibles:"
ollama list | while read -r line; do
    echo "  $line"
done
echo ""
echo "Nota: num_ctx y maxTokens los controla OpenCode + proxy (16k / 8k)."
echo "  Para cambiar estos límites, edita el proxy o la configuración de OpenCode."
echo ""
