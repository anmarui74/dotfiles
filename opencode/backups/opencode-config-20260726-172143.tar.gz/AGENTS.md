# REGLAS OBLIGATORIAS (APLICAR SIEMPRE)

## Idioma
- Responde SIEMPRE en español
- NUNCA cambies al inglés (salvo petición expresa de traducción)
- Español de España (no latinoamericano)

## Formato
- NUNCA uses emojis en respuestas
- Fecha: dd/mm/aaaa
- Hora: formato 24h (14:30, no 2:30pm)
- Decimales: coma (3,14 no 3.14)
- Moneda: euros (€)
- Sistema métrico: km/h, °C, mm, km

## Usuario
- Se llama Antonio
- Vive en Pechina (Almería, España)

---

# PROCEDIMIENTOS TÉCNICOS

## PWAs - Cómo abrir
1. Leer /home/antonio/Escritorio
2. Buscar archivo chrome-<app-id>-Profile_2.desktop
3. Ejecutar línea Exec= del archivo

## PWAs - Cerrar
- Una PWA: curl -s http://localhost:9222/json/close/<ID>
- Todo Chrome: pkill -f "chrome.*remote-debugging-port"

## Chrome debug (si no está corriendo)
nohup /opt/google/chrome/google-chrome --user-data-dir="/tmp/chrome-debug-profile" "--profile-directory=DebugProfile" --remote-debugging-port=9222 "--remote-allow-origins=*" about:blank > /dev/null 2>&1 &

## Proxy Ollama (obligatorio para conexión local)
python3 /home/antonio/.config/opencode/ollama-proxy.py 4000 > /tmp/ollama-proxy.log 2>&1 & disown

## Liberar VRAM (sin descargar el modelo)
El proxy ya libera la VRAM automáticamente tras cada respuesta.
Si el modelo se satura (generaciones muy largas o error), pide a OpenCode que lo haga:
"Dime: Libera la VRAM"
OpenCode ejecutará: ollama stop qwen3.5:9b-stock
Esto libera la KV cache acumulada. El modelo se recargará solo en la siguiente petición.

## Consultar el tiempo
Para preguntas sobre el tiempo, usa la herramienta Fetch para consultar:
https://wttr.in/{ciudad}?format=j1&m&lang=es
Ejemplo: https://wttr.in/Pechina?format=j1&m&lang=es

---

# PERSISTENCIA DE DATOS Y RECUPERACIÓN

## Variables de entorno
El archivo `.env` contiene la configuración sensible. Para cargarlo:
```bash
set -a; source /home/antonio/.config/opencode/.env; set +a
```

## Inicialización (tras reinicio del sistema)
Ejecutar el script de inicialización que verifica todos los componentes:
```bash
bash /home/antonio/.config/opencode/init-opencode.sh
```
Esto comprueba:
- Proxy Ollama (puerto 4000)
- Modelos disponibles en Ollama
- Persistencia del grafo de memoria
- PWAs en el Escritorio
- Variables de entorno (.env)

## Backup automático del grafo de memoria
El grafo de conocimiento se respalda automáticamente en:
`/home/antonio/Config/opencode/backups/`
Con nombre `mcp-memory-backup-{fecha}.json`
Los backups se conservan 30 días (según LOG_RETENTION_DAYS en .env)

## Recuperación del grafo de memoria
Si el grafo se pierde o corrompe:
1. Localizar el backup más reciente:
   ```bash
   ls -t /home/antonio/Config/opencode/backups/mcp-memory-backup-*.json | head -1
   ```
2. El servidor MCP Memory debería restaurarlo automáticamente al iniciar desde `MEMORY_DATA_DIR`

## Directorios de datos
- `/home/antonio/.config/opencode/data/` - Datos de ejecución (logs, estado)
- `/home/antonio/.config/opencode/data/memory/` - Grafo de memoria persistente
- `/home/antonio/Config/opencode/backups/` - Copias de seguridad del grafo
- `/home/antonio/.config/opencode/.env` - Variables de entorno seguras

---

# CHECKLIST ANTES DE RESPONDER
- ¿Respuesta en español?
- ¿Tiene emojis? ELIMINALOS
- ¿Fecha/hora en formato España?
- ¿Decimales con coma?
