#!/usr/bin/env bash
# Inicia LM Studio con el modelo qwen3.5-9b y 80K de contexto
# Ejecutar tras cada reinicio del sistema

set -euo pipefail

LMSTUDIO_BIN="/home/antonio/.lmstudio/bin/lms"
MODELO="qwen/qwen3.5-9b"
CONTEXTO=81920
PUERTO=1234

# Arrancar servidor si no está
if ! $LMSTUDIO_BIN status 2>/dev/null | grep -q "ON"; then
    echo "Arrancando servidor LM Studio..."
    $LMSTUDIO_BIN server start
    sleep 2
fi

# Descargar modelo actual y cargar con contexto grande
$LMSTUDIO_BIN unload "$MODELO" 2>/dev/null
echo "Cargando $MODELO con contexto $CONTEXTO..."
$LMSTUDIO_BIN load "$MODELO" -c $CONTEXTO -y

# Verificar que el contexto se ha aplicado correctamente
CONTEXTO_REAL=$($LMSTUDIO_BIN ps 2>/dev/null | grep "$MODELO" | awk '{print $6}')
if [ "$CONTEXTO_REAL" != "$CONTEXTO" ]; then
    echo "⚠️  Contexto cargado: $CONTEXTO_REAL (esperado: $CONTEXTO). Reintentando..."
    sleep 1
    $LMSTUDIO_BIN unload "$MODELO" 2>/dev/null
    $LMSTUDIO_BIN load "$MODELO" -c $CONTEXTO -y
    CONTEXTO_REAL=$($LMSTUDIO_BIN ps 2>/dev/null | grep "$MODELO" | awk '{print $6}')
fi
echo "   Contexto verificado: $CONTEXTO_REAL"

# Iniciar proxy OpenCode → LM Studio (puerto 4001)
if ! pgrep -f "lmstudio-proxy.py.*4001" > /dev/null 2>&1; then
    nohup python3 "$(dirname "$0")/lmstudio-proxy.py" 4001 > /tmp/lmstudio-proxy.log 2>&1 &
    echo "   Proxy lmstudio-proxy.py iniciado en puerto 4001"
fi

echo "✅ LM Studio listo en puerto $PUERTO con $CONTEXTO de contexto"
