#!/usr/bin/env python3
"""Proxy OpenCode ↔ LM Studio. Cambio automático de modelo."""
import json, http.server, urllib.request, sys, subprocess, time, threading

LM = "http://localhost:1234"
PORT = 4001
LMS = "/home/antonio/.lmstudio/bin/lms"
_loading = False
_load_lock = threading.Lock()
_count = 0  # contador de intentos

def _get_loaded():
    try:
        r = urllib.request.urlopen(urllib.request.Request(f"{LM}/v1/models"), timeout=5)
        return {m['id'] for m in json.load(r).get('data', [])}
    except:
        return set()

def _do_switch(target):
    global _loading
    print(f"[proxy] ⏳ Cargando {target}...", flush=True)
    for m in _get_loaded():
        if m != target and "embedding" not in m.lower():
            subprocess.run([LMS, "unload", m], capture_output=True, timeout=60)
    time.sleep(2)
    r = subprocess.run([LMS, "load", target, "-y"], capture_output=True, text=True, timeout=180)
    if r.returncode == 0:
        print(f"[proxy] ✅ {target}", flush=True)
    else:
        print(f"[proxy] ❌ {target}: {r.stderr[:100]}", flush=True)
    _loading = False

class Proxy(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"
    
    def do_GET(self):
        try:
            r = urllib.request.urlopen(urllib.request.Request(f"{LM}{self.path}"), timeout=10)
            self.send_response(r.status)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(r.read())
        except:
            self.send_error(502, "proxy error")
    
    def do_POST(self):
        global _loading, _count
        if "/chat/completions" not in self.path:
            return self.send_error(404)
        
        raw = self.rfile.read(int(self.headers.get("Content-Length", 0)))
        body = json.loads(raw)
        model = body.get("model", "")
        if model.startswith("lmstudio/"):
            model = model[len("lmstudio/"):]
            body["model"] = model
        
        loaded = _get_loaded()
        
        if model in loaded:
            # Reenviar a LM Studio
            try:
                r = urllib.request.urlopen(urllib.request.Request(
                    f"{LM}{self.path}", data=json.dumps(body).encode(),
                    headers={"Content-Type": "application/json"}), timeout=600)
                self.send_response(r.status)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(r.read())
                return
            except Exception as e:
                self.send_error(502, str(e))
                return
        
        # Modelo no cargado: iniciar carga o esperar
        with _load_lock:
            if not _loading:
                _loading = True
                _count = 0
                threading.Thread(target=_do_switch, args=(model,), daemon=True).start()
        
        _count += 1
        self.send_response(503)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps({
            "error": f"Cargando {model}... (intento {_count})"
        }).encode())

http.server.ThreadingHTTPServer(("127.0.0.1", PORT), Proxy).serve_forever()
