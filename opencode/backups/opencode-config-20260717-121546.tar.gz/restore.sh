#!/usr/bin/env bash
# restore.sh — Restaura configuración de OpenCode desde este respaldo
# Uso: bash restore.sh

set -euo pipefail

echo "=============================================="
echo "  Restaurando configuración de OpenCode..."
echo "=============================================="

HOME_DIR="$HOME"
BACKUP_DIR="$(cd "$(dirname "$0")" && pwd)"

# 1. Configuración principal
echo ">>> Copiando opencode.json..."
mkdir -p "$HOME_DIR/.config/opencode"
cp "$BACKUP_DIR/opencode.json" "$HOME_DIR/.config/opencode/"

if [ -f "$BACKUP_DIR/opencode.jsonc" ]; then
    cp "$BACKUP_DIR/opencode.jsonc" "$HOME_DIR/.config/opencode/"
fi

cp "$BACKUP_DIR/tui.json" "$HOME_DIR/.config/opencode/"
cp "$BACKUP_DIR/AGENTS.md" "$HOME_DIR/.config/opencode/"

# 2. Prompts personalizados
if [ -d "$BACKUP_DIR/prompts" ]; then
    echo ">>> Restaurando prompts personalizados..."
    mkdir -p "$HOME_DIR/.config/opencode/prompts"
    cp -r "$BACKUP_DIR/prompts/"* "$HOME_DIR/.config/opencode/prompts/" 2>/dev/null || true
fi

# 3. Commands personalizados
if [ -d "$BACKUP_DIR/commands" ]; then
    echo ">>> Restaurando commands personalizados..."
    mkdir -p "$HOME_DIR/.config/opencode/commands"
    cp -r "$BACKUP_DIR/commands/"* "$HOME_DIR/.config/opencode/commands/" 2>/dev/null || true
fi

# 4. Scripts de instalacion (setup-voz.sh, bootstrap-ocv.sh)
if [ -f "$BACKUP_DIR/setup-voz.sh" ]; then
    echo ">>> Restaurando setup-voz.sh..."
    mkdir -p "$HOME_DIR/Config/opencode"
    cp "$BACKUP_DIR/setup-voz.sh" "$HOME_DIR/Config/opencode/setup-voz.sh"
fi
if [ -f "$BACKUP_DIR/bootstrap-ocv.sh" ]; then
    echo ">>> Restaurando bootstrap-ocv.sh..."
    cp "$BACKUP_DIR/bootstrap-ocv.sh" "$HOME_DIR/.config/opencode/bootstrap-ocv.sh"
fi

# 5. Proxy
if [ -f "$BACKUP_DIR/ollama-proxy.py" ]; then
    echo ">>> Copiando ollama-proxy.py..."
    cp "$BACKUP_DIR/ollama-proxy.py" "$HOME_DIR/.config/opencode/"
fi

# 6. Plugin de voz
echo ">>> Restaurando plugin opencode-voice..."
PLUGIN_DIR="$HOME_DIR/.config/opencode/opencode-voice-modified"
rm -rf "$PLUGIN_DIR"
mkdir -p "$PLUGIN_DIR/lib"
cp "$BACKUP_DIR/plugin/index.js" "$PLUGIN_DIR/"
cp "$BACKUP_DIR/plugin/lib/stt.js" "$PLUGIN_DIR/lib/"
cp "$BACKUP_DIR/plugin/lib/tts.js" "$PLUGIN_DIR/lib/"
cp "$BACKUP_DIR/plugin/lib/session.js" "$PLUGIN_DIR/lib/"
cp "$BACKUP_DIR/plugin/lib/logger.js" "$PLUGIN_DIR/lib/"
cp "$BACKUP_DIR/plugin/lib/llm-client.js" "$PLUGIN_DIR/lib/"

# Copiar package.json del original si existe
if [ -d "/usr/lib/node_modules/@renjfk/opencode-voice" ]; then
    cp "/usr/lib/node_modules/@renjfk/opencode-voice/package.json" "$PLUGIN_DIR/"
    cp "/usr/lib/node_modules/@renjfk/opencode-voice/LICENSE" "$PLUGIN_DIR/" 2>/dev/null || true
fi

# 8. speak script
echo ">>> Instalando speak..."
mkdir -p "$HOME_DIR/.local/bin"
cp "$BACKUP_DIR/speak" "$HOME_DIR/.local/bin/"
chmod +x "$HOME_DIR/.local/bin/speak"

# 9. whisper wrapper
if [ -f "$BACKUP_DIR/whisper-cli" ]; then
    echo ">>> Instalando whisper-cli..."
    cp "$BACKUP_DIR/whisper-cli" "$HOME_DIR/.local/bin/"
    chmod +x "$HOME_DIR/.local/bin/whisper-cli"
fi

# 10. Añadir función ocv y PATH a .zshrc
if [ -f "$BACKUP_DIR/zshrc-ocv.txt" ] && [ -s "$BACKUP_DIR/zshrc-ocv.txt" ]; then
    if ! grep -q "function ocv" "$HOME_DIR/.zshrc" 2>/dev/null; then
        echo "" >> "$HOME_DIR/.zshrc"
        echo "# OCV - OpenCode con voz" >> "$HOME_DIR/.zshrc"
        cat "$BACKUP_DIR/zshrc-ocv.txt" >> "$HOME_DIR/.zshrc"
        echo ">>> función ocv añadida a .zshrc"
    else
        echo ">>> función ocv ya existe en .zshrc"
    fi
fi

if [ -f "$BACKUP_DIR/zshrc-path.txt" ] && [ -s "$BACKUP_DIR/zshrc-path.txt" ]; then
    if ! grep -q '\.local/bin' "$HOME_DIR/.zshrc" 2>/dev/null; then
        cat "$BACKUP_DIR/zshrc-path.txt" >> "$HOME_DIR/.zshrc"
        echo ">>> PATH añadido a .zshrc"
    fi
fi

# 11. Restaurar kv.json (estado TTS y otros)
if [ -f "$BACKUP_DIR/state/kv.json" ]; then
    echo ">>> Restaurando kv.json (estado)..."
    mkdir -p "$HOME_DIR/.local/state/opencode"
    # Mantener tts.mode si ya existe, si no usar el del backup
    if [ -f "$HOME_DIR/.local/state/opencode/kv.json" ]; then
        # Fusionar: mantener tts.mode del backup
        BACKUP_TTS=$(python3 -c "import json; d=json.load(open('$BACKUP_DIR/state/kv.json')); print(d.get('tts.mode','on'))" 2>/dev/null || echo "on")
        python3 -c "
import json
with open('$HOME_DIR/.local/state/opencode/kv.json') as f: d=json.load(f)
d['tts.mode']='$BACKUP_TTS'
with open('$HOME_DIR/.local/state/opencode/kv.json','w') as f: json.dump(d,f)
" 2>/dev/null || cp "$BACKUP_DIR/state/kv.json" "$HOME_DIR/.local/state/opencode/kv.json"
    else
        cp "$BACKUP_DIR/state/kv.json" "$HOME_DIR/.local/state/opencode/kv.json"
    fi
fi

echo ""
echo "=============================================="
echo "  Restauración completada"
echo "=============================================="
echo "Recarga: source ~/.zshrc"
echo "Luego ejecuta: ocv"
