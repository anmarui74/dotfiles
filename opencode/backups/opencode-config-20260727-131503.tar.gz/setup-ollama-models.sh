#!/usr/bin/env bash
# setup-ollama-models.sh — Descarga modelos y crea variantes con contexto 16k
# Uso: bash setup-ollama-models.sh
# Este script prepara todos los modelos locales para OpenCode con tool calling

set -euo pipefail

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

info()  { echo -e "${GREEN}[✓]${NC} $1"; }
warn()  { echo -e "${YELLOW}[!]${NC} $1"; }
err()   { echo -e "${RED}[✗]${NC} $1"; }

echo "=============================================="
echo "  Configuración de modelos Ollama para OpenCode"
echo "=============================================="
echo ""

# Lista de modelos base y sus variantes 16k
declare -A MODELS=(
    ["qwen3.5:9b-stock"]="qwen3.5:9b-16k"
    ["llama3.1:8b"]="llama3.1:8b-16k"
    ["gemma4:e4b"]="gemma4:e4b-16k"
    ["deepseek-r1:8b"]="deepseek-r1:8b-16k"
    ["deepseek-v4-flash-stock:latest"]="deepseek-v4-flash-stock:latest-16k"
)

# Verificar que Ollama está corriendo
if ! pgrep -x "ollama" > /dev/null; then
    err "Ollama no está corriendo. Inícialo con: ollama serve"
    exit 1
fi

info "Ollama está corriendo"

# Crear directorio temporal para Modelfiles
TMPDIR=$(mktemp -d)
trap "rm -rf $TMPDIR" EXIT

# Procesar cada modelo
for base_model in "${!MODELS[@]}"; do
    variant_model="${MODELS[$base_model]}"
    
    echo ""
    echo "--- Procesando: $base_model → $variant_model ---"
    
    # 1. Verificar/descargar modelo base
    if ollama list | grep -q "^${base_model}[[:space:]]"; then
        info "Modelo base $base_model ya descargado"
    else
        warn "Descargando $base_model (esto puede tardar varios minutos)..."
        if ollama pull "$base_model"; then
            info "Modelo $base_model descargado correctamente"
        else
            err "Error al descargar $base_model"
            continue
        fi
    fi
    
    # 2. Verificar si la variante -16k ya existe
    if ollama list | grep -q "^${variant_model}[[:space:]]"; then
        info "Variante $variant_model ya existe"
    else
        # 3. Crear Modelfile con contexto 16k
        modelfile="$TMPDIR/Modelfile-${base_model//[:\/]/-}"
        cat > "$modelfile" << EOF
FROM ${base_model}
PARAMETER num_ctx 16384
EOF
        
        # 4. Crear variante
        info "Creando variante $variant_model con contexto 16384..."
        if ollama create "$variant_model" -f "$modelfile" > /dev/null 2>&1; then
            info "Variante $variant_model creada correctamente"
        else
            err "Error al crear variante $variant_model"
        fi
    fi
    
    # 5. Verificar capacidades del modelo
    if ollama show "$base_model" 2>/dev/null | grep -q "tools"; then
        info "Modelo $base_model soporta tool calling ✓"
    else
        warn "Modelo $base_model NO soporta tool calling"
    fi
done

echo ""
echo "=============================================="
echo "  Resumen de modelos configurados"
echo "=============================================="
echo ""

# Mostrar modelos -16k creados
echo "Modelos con contexto 16k disponibles:"
ollama list | grep "16k" | while read -r line; do
    echo "  $line"
done

echo ""
echo "=============================================="
echo "  Configuración completada"
echo "=============================================="
echo ""
echo "Próximos pasos:"
echo "  1. Reinicia OpenCode para cargar la nueva configuración"
echo "  2. Los modelos -16k están listos para usar con tool calling"
echo "  3. Usa: opencode run -m ollama/<modelo-16k> 'tu consulta'"
echo ""
