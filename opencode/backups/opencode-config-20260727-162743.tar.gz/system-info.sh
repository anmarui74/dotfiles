#!/usr/bin/env zsh
#
# script: system-info.sh
# Descripción:  Recolecta información del sistema y la muestra como Markdown
# Autor:        Antonio (vía OpenCode)
# Sistema:      Arch Linux / CachyOS
#

# ──────────────────────────────────────────────
# Configuración regional (decimal con coma)
# ──────────────────────────────────────────────
export LC_NUMERIC=es_ES.UTF-8 2>/dev/null || true

# ──────────────────────────────────────────────
# Encabezado
# ──────────────────────────────────────────────
print "# 📋 Información del sistema"
print
print "Generado el **$(date '+%d/%m/%Y a las %H:%M')**"
print

# ──────────────────────────────────────────────
# 1. SISTEMA OPERATIVO
# ──────────────────────────────────────────────
print "## 🖥️  Sistema operativo"
print

if [[ -f /etc/os-release ]]; then
    source /etc/os-release
    print "| Campo | Valor |"
    print "|-------|-------|"
    print "| **Distribución** | ${PRETTY_NAME:-$NAME} |"
    print "| **ID** | ${ID:-desconocido} |"
    print "| **Arquitectura** | $(uname -m) |"
    print "| **Kernel** | $(uname -r) |"
    print "| **Hostname** | $(hostname) |"
    print "| **Uptime** | ${_uptime_es} |"
fi
print

# ──────────────────────────────────────────────
# 1b. PLACA BASE
# ──────────────────────────────────────────────
print "## 🔧 Placa base"
print

_board_vendor=$(cat /sys/class/dmi/id/board_vendor 2>/dev/null || echo "desconocido")
_board_name=$(cat /sys/class/dmi/id/board_name 2>/dev/null || echo "desconocido")
_board_version=$(cat /sys/class/dmi/id/board_version 2>/dev/null || echo "desconocido")
_bios_vendor=$(cat /sys/class/dmi/id/bios_vendor 2>/dev/null || echo "desconocido")
_bios_version=$(cat /sys/class/dmi/id/bios_version 2>/dev/null || echo "desconocido")
_bios_date=$(cat /sys/class/dmi/id/bios_date 2>/dev/null || echo "desconocido")

print "| Campo | Valor |"
print "|-------|-------|"
print "| **Fabricante** | $_board_vendor |"
print "| **Modelo** | $_board_name |"
print "| **Versión** | $_board_version |"
print "| **BIOS** | $_bios_vendor |"
print "| **Versión BIOS** | $_bios_version |"
print "| **Fecha BIOS** | $_bios_date |"
print

# ──────────────────────────────────────────────
# 2. CPU
# ──────────────────────────────────────────────
print "## 🧠 CPU"
print

if command -v lscpu &>/dev/null; then
    cpu_model=$(lscpu | grep "Nombre del modelo" | awk -F': *' '{print $2}')
    cpu_sockets=$(lscpu | grep "Socket" | head -1 | awk -F': *' '{print $2}')
    cpu_cores=$(lscpu | grep "Núcleo" | head -1 | awk -F': *' '{print $2}')
    cpu_threads=$(lscpu | grep "^CPU(s):" | awk -F': *' '{print $2}')
    cpu_max=$(lscpu | grep "CPU MHz máx" | awk -F': *' '{print $2}')
    cpu_min=$(lscpu | grep "CPU MHz mín" | awk -F': *' '{print $2}')
    cpu_l1d=$(lscpu | grep "Caché L1d" | awk -F': *' '{print $2}')
    cpu_l1i=$(lscpu | grep "Caché L1i" | awk -F': *' '{print $2}')
    cpu_l2=$(lscpu | grep "Caché L2" | awk -F': *' '{print $2}')
    cpu_l3=$(lscpu | grep "Caché L3" | awk -F': *' '{print $2}')

    print "| Campo | Valor |"
    print "|-------|-------|"
    print "| **Modelo** | ${cpu_model:-desconocido} |"
    print "| **Sockets** | ${cpu_sockets:-?} |"
    print "| **Núcleos físicos** | ${cpu_cores:-?} |"
    print "| **Hilos (threads)** | ${cpu_threads:-?} |"
    print "| **Frecuencia máx** | ${$(printf '%.0f' ${cpu_max:-0})%,*} MHz |"
    print "| **Frecuencia mín** | ${$(printf '%.0f' ${cpu_min:-0})%,*} MHz |"
    print "| **Caché L1d** | ${cpu_l1d:-?} |"
    print "| **Caché L1i** | ${cpu_l1i:-?} |"
    print "| **Caché L2** | ${cpu_l2:-?} |"
    print "| **Caché L3** | ${cpu_l3:-?} |"

    # Vulnerabilidades (solo las relevantes)
    print "| **Spectre v2** | $(lscpu | grep 'Vulnerabilidad Spectre v2' | awk -F': *' '{print $2}') |"
    print "| **Retbleed** | $(lscpu | grep 'Vulnerabilidad Retbleed' | awk -F': *' '{print $2}') |"
    print "| **Meltdown** | $(lscpu | grep 'Vulnerabilidad Meltdown' | awk -F': *' '{print $2}') |"
fi
print

# ──────────────────────────────────────────────
# 3. GPU
# ──────────────────────────────────────────────
print "## 🎮 GPU"
print

if command -v lspci &>/dev/null; then
    # GPU dedicada (NVIDIA)
    nvidia_line=$(lspci | grep -i "VGA.*NVIDIA\|3D.*NVIDIA")
    if [[ -n $nvidia_line ]]; then
        nvidia_model=$(echo "$nvidia_line" | sed 's/.*\[\(.*\)\].*/\1/' | head -1)
        [[ -z $nvidia_model ]] && nvidia_model=$(echo "$nvidia_line" | awk -F': ' '{print $2}')

        print "### GPU dedicada (NVIDIA)"
        print
        print "| Campo | Valor |"
        print "|-------|-------|"
        print "| **Modelo** | ${nvidia_model:-NVIDIA} |"

        if command -v nvidia-smi &>/dev/null; then
            nvidia_vram=$(nvidia-smi --query-gpu=memory.total --format=csv,noheader 2>/dev/null | awk '{print $1}')
            nvidia_driver=$(nvidia-smi --query-gpu=driver_version --format=csv,noheader 2>/dev/null)
            nvidia_temp=$(nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader 2>/dev/null)
            print "| **VRAM** | ${nvidia_vram:-?} MiB |"
            print "| **Driver** | ${nvidia_driver:-?} |"
            print "| **Temperatura** | ${nvidia_temp:-?}°C |"
        fi
        print
    fi

    # GPU integrada (AMD)
    amd_line=$(lspci | grep -i "VGA.*AMD\|VGA.*ATI\|Display.*AMD\|Display controller.*AMD" | grep -v "NVIDIA")
    if [[ -n $amd_line ]]; then
        # Intentar extraer nombre entre corchetes, o tras el ": "
        amd_model=$(echo "$amd_line" | sed -n 's/.*\[\(AMD\/ATI\)\? *\([^]]*\)\].*/\2/p')
        [[ -z $amd_model ]] && amd_model=$(echo "$amd_line" | sed 's/.*: //' | sed 's/ (.*//')

        print "### GPU integrada (AMD)"
        print
        print "| Campo | Valor |"
        print "|-------|-------|"
        print "| **Modelo** | ${amd_model:-AMD iGPU (Radeon Graphics)} |"
        print "| **Driver** | amdgpu |"
        print
    fi

    # Si no se encontró ninguna GPU
    if [[ -z $nvidia_line && -z $amd_line ]]; then
        lspci | grep -E "VGA|3D|Display" | while read -r line; do
            print "- $line"
        done
        print
    fi
fi

# ──────────────────────────────────────────────
# 4. MEMORIA RAM
# ──────────────────────────────────────────────
print "## 💾 Memoria RAM"
print

if command -v free &>/dev/null; then
    mem_total=$(free -h | awk '/^Mem:/ {print $2}')
    mem_used=$(free -h | awk '/^Mem:/ {print $3}')
    mem_avail=$(free -h | awk '/^Mem:/ {print $7}')
    swap_total=$(free -h | awk '/^Swap:/ {print $2}')
    swap_used=$(free -h | awk '/^Swap:/ {print $3}')

    print "| Campo | Valor |"
    print "|-------|-------|"
    print "| **Total** | $mem_total |"
    print "| **Usado** | $mem_used |"
    print "| **Disponible** | $mem_avail |"
    print "| **Swap total** | ${swap_total:-0} |"
    print "| **Swap usado** | ${swap_used:-0} |"
    print

    # Intentar obtener detalles de la RAM (requiere sudo)
    if command -v dmidecode &>/dev/null; then
        _dmi17=$(sudo -n dmidecode -t 17 2>/dev/null)
        _dmi16=$(sudo -n dmidecode -t 16 2>/dev/null)
        if echo "$_dmi17" | grep -q "Memory Device"; then

            # ── Physical Memory Array (type 16) ──
            _max_cap=$(echo "$_dmi16" | grep "Maximum Capacity" | awk -F': ' '{print $2}' | sed 's/^ *//')
            _num_slots=$(echo "$_dmi16" | grep "Number Of Devices" | awk -F': ' '{print $2}' | sed 's/^ *//')

            # ── Parsear cada bloque de Memory Device con awk ──
            # Separamos por "Handle" (cada device) y extraemos campos con field separators
            _parsed=$(echo "$_dmi17" | awk '
                /^Handle/ {
                    # Al empezar un nuevo device, imprimir el anterior (si existe)
                    if (loc != "") {
                        if (size ~ /No Module|None|No [Mm]odule Installed/ || size == "") {
                            state = "vacío"
                            sz = "—"; tp = "—"; sp = "—"; rk = "—"; pn = "—"
                        } else {
                            state = "ocupado"
                            sz = size; tp = mtype; sp = speed; rk = rank; pn = part
                        }
                        gsub(/^[[:space:]]+|[[:space:]]+$/, "", loc)
                        gsub(/^[[:space:]]+|[[:space:]]+$/, "", sz)
                        gsub(/^[[:space:]]+|[[:space:]]+$/, "", tp)
                        gsub(/^[[:space:]]+|[[:space:]]+$/, "", sp)
                        gsub(/^[[:space:]]+|[[:space:]]+$/, "", rk)
                        gsub(/^[[:space:]]+|[[:space:]]+$/, "", pn)
                        printf "%s|%s|%s|%s|%s|%s|%s\n", loc, state, sz, tp, sp, rk, pn
                    }
                    loc = ""; size = ""; mtype = ""; speed = ""; rank = ""; part = ""
                }
                /^[[:space:]]+Locator:[[:space:]]/ {
                    sub(/^[[:space:]]+Locator:[[:space:]]+/, ""); loc = $0
                }
                /^[[:space:]]+Size:[[:space:]]/ {
                    sub(/^[[:space:]]+Size:[[:space:]]+/, ""); size = $0
                }
                /^[[:space:]]+Type:[[:space:]]/ {
                    # Ignorar "Type Detail" y "Type: Unknown" como primer tipo
                    if ($0 !~ /Type Detail/) {
                        sub(/^[[:space:]]+Type:[[:space:]]+/, ""); mtype = $0
                    }
                }
                /^[[:space:]]+Speed:[[:space:]]/ {
                    sub(/^[[:space:]]+Speed:[[:space:]]+/, ""); speed = $0
                }
                /^[[:space:]]+Rank:[[:space:]]/ {
                    sub(/^[[:space:]]+Rank:[[:space:]]+/, ""); rank = $0
                }
                /^[[:space:]]+Part Number:[[:space:]]/ {
                    sub(/^[[:space:]]+Part Number:[[:space:]]+/, ""); part = $0
                }
                END {
                    # Último device
                    if (loc != "") {
                        if (size ~ /No Module|None|No [Mm]odule Installed/ || size == "") {
                            state = "vacío"
                            sz = "—"; tp = "—"; sp = "—"; rk = "—"; pn = "—"
                        } else {
                            state = "ocupado"
                            sz = size; tp = mtype; sp = speed; rk = rank; pn = part
                        }
                        gsub(/^[[:space:]]+|[[:space:]]+$/, "", loc)
                        gsub(/^[[:space:]]+|[[:space:]]+$/, "", sz)
                        gsub(/^[[:space:]]+|[[:space:]]+$/, "", tp)
                        gsub(/^[[:space:]]+|[[:space:]]+$/, "", sp)
                        gsub(/^[[:space:]]+|[[:space:]]+$/, "", rk)
                        gsub(/^[[:space:]]+|[[:space:]]+$/, "", pn)
                        printf "%s|%s|%s|%s|%s|%s|%s\n", loc, state, sz, tp, sp, rk, pn
                    }
                }
            ')

            # ── Recorrer las líneas parseadas ──
            typeset -a _mod_locators _mod_states _mod_sizes _mod_types _mod_speeds _mod_ranks _mod_parts
            _mod_count=0
            _mod_occupied=0
            while IFS='|' read -r _loc _state _size _type _speed _rank _part; do
                _mod_locators+=("$_loc")
                _mod_states+=("$_state")
                _mod_sizes+=("$_size")
                _mod_types+=("$_type")
                _mod_speeds+=("$_speed")
                _mod_ranks+=("$_rank")
                _mod_parts+=("$_part")
                [[ "$_state" == "ocupado" ]] && _mod_occupied=$(( _mod_occupied + 1 ))
                _mod_count=$(( _mod_count + 1 ))
            done <<< "$_parsed"

            # ── Datos agregados ──
            _mem_type=""; _mem_speed=""; _mem_rank=""; _mem_part=""; _mem_size=""
            for _i in {1..${#_mod_types[@]}}; do
                [[ -z "$_mem_type" && "${_mod_types[$_i]}" != "—" && "${_mod_types[$_i]}" != "Unknown" ]] && _mem_type="${_mod_types[$_i]}"
                [[ -z "$_mem_speed" && "${_mod_speeds[$_i]}" != "—" && "${_mod_speeds[$_i]}" != "Unknown" ]] && _mem_speed="${_mod_speeds[$_i]}"
                [[ -z "$_mem_rank" && "${_mod_ranks[$_i]}" != "—" ]] && _mem_rank="${_mod_ranks[$_i]}"
                [[ -z "$_mem_part" && "${_mod_parts[$_i]}" != "—" ]] && _mem_part="${_mod_parts[$_i]}"
                [[ -z "$_mem_size" && "${_mod_sizes[$_i]}" != "—" ]] && _mem_size="${_mod_sizes[$_i]}"
            done

            # Velocidad configurada
            _configured_speed=$(echo "$_dmi17" | grep "Configured Memory Speed:" | grep -iv "unknown" | head -1 | awk -F': ' '{print $2}' | sed 's/^ *//')

            # Inferir tipo DDR si no está claro
            if [[ "$_mem_type" = "Unknown" || -z $_mem_type ]]; then
                if [[ -n $_mem_part ]]; then
                    case "$_mem_part" in
                        *X5*|*DDR5*|*5600*|*6000*|*6400*|*7200*|*7600*) _mem_type="DDR5" ;;
                        *X4*|*DDR4*|*3200*|*3600*) _mem_type="DDR4" ;;
                        *) _mem_type="DDR5 (inferido)" ;;
                    esac
                else
                    _mem_type="DDR5"
                fi
            fi

            # Velocidad SPD base
            _spd_speed="4800 MT/s"

            # ── Mostrar tabla general ──
            print "### Visión general"
            print
            print "| Campo | Valor |"
            print "|-------|-------|"
            print "| **Capacidad máxima** | ${_max_cap:-?} |"
            print "| **Slots totales** | ${_num_slots:-?} |"
            print "| **Slots ocupados** | $_mod_occupied |"
            print "| **Tipo** | $_mem_type |"
            print "| **Velocidad SPD (base)** | $_spd_speed |"
            print "| **Velocidad configurada** | ${_configured_speed:-$_mem_speed} |"
            [[ -n $_mem_rank ]] && print "| **Rank por módulo** | $_mem_rank |"
            [[ -n $_mem_part ]] && print "| **Nº de pieza** | $_mem_part |"
            print

            # ── Tabla por slots ──
            print "### Estado de los slots"
            print
            print "| Slot | Estado | Tamaño | Tipo | Velocidad | Rank |"
            print "|------|--------|--------|------|-----------|------|"
            for _i in {1..$_mod_count}; do
                printf "| %s | %s | %s | %s | %s | %s |\n" \
                    "${_mod_locators[$_i]}" "${_mod_states[$_i]}" \
                    "${_mod_sizes[$_i]}" "${_mod_types[$_i]}" \
                    "${_mod_speeds[$_i]}" "${_mod_ranks[$_i]}"
            done
            print

            # ── Latencia: inferir del nº de pieza ──
            if [[ -n $_mem_part ]]; then
                _jedec_lat=""; _expo_lat=""; _expo_volt=""
                case "$_mem_part" in
                    *Z30|*Z30*)
                        _jedec_lat="40-40-40-77"
                        _expo_lat="30-36-36-76"
                        _expo_volt="1,40 V"
                        ;;
                    *Z36|*Z36*)
                        _jedec_lat="40-40-40-77"
                        _expo_lat="36-38-38-76"
                        _expo_volt="1,35 V"
                        ;;
                esac

                if [[ -n $_expo_lat ]]; then
                    print "### Latencias (por modelo)"
                    print
                    print "| Perfil | Velocidad | Latencia (CL-tRCD-tRP-tRAS) | Voltaje |"
                    print "|--------|-----------|-----------------------------|---------|"
                    print "| 🔵 **JEDEC (base)** | $_spd_speed | $_jedec_lat | 1,10 V |"
                    print "| 🟢 **EXPO (actual)** | ${_configured_speed:-$_mem_speed} | $_expo_lat | $_expo_volt |"
                    print
                fi
            fi
        else
            print "> ⚠️  No se pudo leer el tipo de RAM (ejecuta con \`sudo\` para ver detalles de los módulos)."
            print
        fi
    fi
fi

# ──────────────────────────────────────────────
# 5. ETHERNET
# ──────────────────────────────────────────────
print "## 🌐 Ethernet"
print

_eth_dev=$(lspci 2>/dev/null | grep -i "ethernet" | head -1)
if [[ -n $_eth_dev ]]; then
    _eth_model=$(echo "$_eth_dev" | sed 's/.*: //')
    _eth_bus=$(echo "$_eth_dev" | awk '{print $1}' | sed 's/://')
    _eth_driver=$(lspci -v -s "$_eth_bus" 2>/dev/null | grep "Kernel driver" | awk -F': ' '{print $2}' | sed 's/^ *//')
    [[ -z $_eth_driver ]] && _eth_driver="r8169 (por defecto)"
    _eth_iface=$(ip link show 2>/dev/null | grep -B1 "34:5a:60:52:b8:58" | head -1 | awk -F': ' '{print $2}' | awk '{print $1}')
    _eth_status=$(ip link show "$_eth_iface" 2>/dev/null | grep -o "state [A-Z]*" | awk '{print $2}')
    _eth_mac="34:5a:60:52:b8:58"
    _eth_speed=""
    if command -v ethtool &>/dev/null; then
        _eth_speed=$(sudo -n ethtool "$_eth_iface" 2>/dev/null | grep "Speed:" | awk '{print $2}')
    fi

    print "| Campo | Valor |"
    print "|-------|-------|"
    print "| **Modelo** | $_eth_model |"
    [[ -n $_eth_driver ]] && print "| **Driver** | $_eth_driver |"
    [[ -n $_eth_iface ]] && print "| **Interfaz** | $_eth_iface |"
    print "| **MAC** | $_eth_mac |"
    [[ -n $_eth_status ]] && print "| **Estado** | $_eth_status |"
    [[ -n $_eth_speed ]] && print "| **Velocidad** | $_eth_speed |"
    [[ "$_eth_status" == "DOWN" ]] && print "| **Nota** | Sin cable conectado (usando WiFi) |"
    print
else
    print "> ℹ️  No se detectó tarjeta Ethernet."
    print
fi

# ──────────────────────────────────────────────
# 7. WIFI
# ──────────────────────────────────────────────
print "## 📡 WiFi"
print

if command -v iw &>/dev/null; then
    _wifi_iface=$(iw dev 2>/dev/null | awk '/Interface/ {print $2}' | head -1)
    if [[ -n $_wifi_iface ]]; then
        _wifi_link=$(iw dev "$_wifi_iface" link 2>/dev/null)
        _wifi_ssid=$(echo "$_wifi_link" | grep "SSID:" | awk '{print $2}')
        _wifi_freq=$(echo "$_wifi_link" | grep "freq:" | awk '{print $2}')
        _wifi_signal=$(echo "$_wifi_link" | grep "signal:" | awk '{print $2}')
        _wifi_rx=$(echo "$_wifi_link" | grep "rx bitrate:" | sed 's/.*rx bitrate: //' | head -1)
        _wifi_tx=$(echo "$_wifi_link" | grep "tx bitrate:" | sed 's/.*tx bitrate: //' | head -1)
        _wifi_mac=$(iw dev "$_wifi_iface" info 2>/dev/null | grep addr | awk '{print $2}')

        print "| Campo | Valor |"
        print "|-------|-------|"
        [[ -n $_wifi_ssid ]] && print "| **SSID** | $_wifi_ssid |"
        [[ -n $_wifi_freq ]] && print "| **Frecuencia** | $_wifi_freq MHz |"
        [[ -n $_wifi_signal ]] && print "| **Señal** | $_wifi_signal dBm |"
        [[ -n $_wifi_rx ]] && print "| **Velocidad RX** | $_wifi_rx |"
        [[ -n $_wifi_tx ]] && print "| **Velocidad TX** | $_wifi_tx |"
        [[ -n $_wifi_mac ]] && print "| **MAC** | $_wifi_mac |"
        print
    fi

    # Detalles del hardware WiFi
    _wifi_hw=$(lspci 2>/dev/null | grep -i "network\|wireless")
    if [[ -n $_wifi_hw ]]; then
        _wifi_model=$(echo "$_wifi_hw" | sed 's/.*: //')
        _wifi_driver=$(lspci -v -s "$(echo "$_wifi_hw" | awk '{print $1}')" 2>/dev/null | grep "Kernel driver" | awk -F': ' '{print $2}' | sed 's/^ *//')
        _wifi_subsys=$(lspci -v -s "$(echo "$_wifi_hw" | awk '{print $1}')" 2>/dev/null | grep "Subsystem" | awk -F': ' '{print $2}' | sed 's/^ *//')

        print "### Hardware WiFi"
        print
        print "| Campo | Valor |"
        print "|-------|-------|"
        print "| **Modelo** | ${_wifi_model:-?} |"
        [[ -n $_wifi_driver ]] && print "| **Driver** | $_wifi_driver |"
        [[ -n $_wifi_subsys ]] && print "| **Subsistema** | $_wifi_subsys |"
        print
    fi
else
    print "> ℹ️  \`iw\` no disponible para consultar WiFi."
    print
fi

# ──────────────────────────────────────────────
# 8. BLUETOOTH
# ──────────────────────────────────────────────
print "## 🔵 Bluetooth"
print

if command -v bluetoothctl &>/dev/null; then
    _bt_info=$(bluetoothctl show 2>/dev/null)
    if [[ -n $_bt_info ]]; then
        _bt_mac=$(echo "$_bt_info" | head -1 | awk '{print $2}')
        _bt_name=$(echo "$_bt_info" | grep "Name:" | awk '{print $2}')
        _bt_powered=$(echo "$_bt_info" | grep "Powered:" | awk '{print $2}')
        _bt_discoverable=$(echo "$_bt_info" | grep "Discoverable:" | awk '{print $2}' | head -1)
        _bt_pairable=$(echo "$_bt_info" | grep "Pairable:" | awk '{print $2}' | head -1)

        print "| Campo | Valor |"
        print "|-------|-------|"
        print "| **Controlador** | ${_bt_mac:-?} |"
        [[ -n $_bt_name ]] && print "| **Nombre** | $_bt_name |"
        [[ -n $_bt_powered ]] && print "| **Encendido** | $_bt_powered |"
        [[ -n $_bt_discoverable ]] && print "| **Descubrible** | $_bt_discoverable |"
        [[ -n $_bt_pairable ]] && print "| **Emparejable** | $_bt_pairable |"

        # Dispositivos emparejados
        _bt_devices=$(bluetoothctl devices 2>/dev/null)
        _bt_count=$(echo "$_bt_devices" | grep -c .)
        if [[ $_bt_count -gt 0 ]]; then
            print "| **Dispositivos emparejados** | $_bt_count |"
        fi
        print

        # Mostrar dispositivos emparejados
        if [[ $_bt_count -gt 0 ]]; then
            print "#### Dispositivos emparejados"
            print
            print "| MAC | Nombre |"
            print "|-----|--------|"
            echo "$_bt_devices" | while read -r _line; do
                # Formato: "Device <MAC> <Nombre con espacios>"
                _bt_mac=$(echo "$_line" | awk '{print $2}')
                _bt_name=$(echo "$_line" | awk '{for(i=3;i<=NF;i++) printf "%s ", $i; print ""}' | sed 's/ *$//')
                print "| $_bt_mac | $_bt_name |"
            done
            print
        fi
    fi

    # Hardware Bluetooth
    _bt_hw=$(lspci 2>/dev/null | grep -i "bluetooth\|bt\|wireless" | head -3)
    if [[ -z $_bt_hw ]]; then
        # Puede ir por USB
        _bt_usb=$(lsusb 2>/dev/null | grep -i "bluetooth\|qualcomm\|qcnfa\|wcn")
        if [[ -n $_bt_usb ]]; then
            print "> ℹ️  Bluetooth integrado en el chipset Qualcomm (USB interno)."
            print
        fi
    fi
else
    print "> ℹ️  \`bluetoothctl\` no disponible."
    print
fi

# ──────────────────────────────────────────────
# 9. DISPOSITIVOS USB
# ──────────────────────────────────────────────
print "## 🔌 Dispositivos USB destacados"
print

if command -v lsusb &>/dev/null; then
    _usb_count=$(lsusb 2>/dev/null | wc -l)
    print "| Campo | Valor |"
    print "|-------|-------|"
    print "| **Total dispositivos USB** | $_usb_count |"
    print

    # Mostrar tabla de dispositivos relevantes
    print "| Dispositivo | Fabricante | Descripción |"
    print "|-------------|------------|-------------|"
    lsusb 2>/dev/null | while read -r _bus _dev _id _vendor _rest; do
        _desc=$(echo "$_rest" | sed 's/^[^ ]* //' 2>/dev/null)
        print "| $_bus $_dev ($_id) | $_vendor | $_desc |"
    done
    print
else
    print "> ℹ️  \`lsusb\` no disponible."
    print
fi

# ──────────────────────────────────────────────
# 10. ALMACENAMIENTO
# ──────────────────────────────────────────────
print "## 💽 Almacenamiento"
print

if command -v lsblk &>/dev/null; then
    print "\`\`\`"
    lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINT,MODEL 2>/dev/null | grep -v loop
    print "\`\`\`"
    print
fi

if command -v df &>/dev/null; then
    print "### Uso de particiones principales"
    print
    print "\`\`\`"
    df -h / /home /var 2>/dev/null || df -h / 2>/dev/null
    print "\`\`\`"
    print
fi

# ──────────────────────────────────────────────
# 9. RED
# ──────────────────────────────────────────────
print "## 🌐 Red"
print

if command -v ip &>/dev/null; then
    print "\`\`\`"
    ip -4 addr show | grep -E "inet " | awk '{print $2, $NF}'
    print "\`\`\`"
    print
fi

# ──────────────────────────────────────────────
# Pie
# ──────────────────────────────────────────────
print "---"
print "_Generado con \`$(basename "$0")\` en $(date '+%d/%m/%Y a las %H:%M')_"
