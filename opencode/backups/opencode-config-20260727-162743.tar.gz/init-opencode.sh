#!/bin/bash
# Script de inicialización de OpenCode
# Verifica componentes y estado del sistema

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${SCRIPT_DIR}/opencode.json"
LOG_FILE="${SCRIPT_DIR}/data/init.log"
DATA_DIR="${SCRIPT_DIR}/data"

# Crear directorio de datos si no existe
mkdir -p "$DATA_DIR"

# Inicializar log de inicialización
echo "=== Inicialización OpenCode - $(date '+%d/%m/%Y %H:%M') ===" > "$LOG_FILE"
echo "" >> "$LOG_FILE"

log() {
    echo "[$(date '+%H:%M')] $1" | tee -a "$LOG_FILE"
}

# Función para verificar si un proceso está corriendo
check_process() {
    local process_name=$1
    if pgrep -f "$process_name" > /dev/null 2>&1; then
        log "✅ El proceso '$process_name' ya está ejecutándose."
        return 0
    else
        log "❌ El proceso '$process_name' NO está ejecutándose."
        return 1
    fi
}

# Función para verificar disponibilidad de modelos Ollama
check_models() {
    local port=${OLLAMA_PROXY_PORT:-4000}
    log "" >> "$LOG_FILE"
    log "Verificando conexión con Ollama (puerto $port)..."
    
    # Esperar un momento por si el servicio está iniciándose
    sleep 2
    
    if curl -s http://localhost:${port}/api/tags > /dev/null 2>&1; then
        log "✅ Conexión a Ollama establecida."
        
        # Listar modelos disponibles
        local models_response=$(curl -s http://localhost:${port}/api/tags)
        echo "$models_response" | grep -o '"name":"[^"]*"' | cut -d'"' -f4 > "${DATA_DIR}/available_models.txt" 2>/dev/null || true
        
        if [ -f "${DATA_DIR}/available_models.txt" ]; then
            log "📦 Modelos disponibles:" >> "$LOG_FILE"
            while IFS= read -r model; do
                log "   - $model" >> "$LOG_FILE"
            done < "${DATA_DIR}/available_models.txt"
        else
            log "⚠️ No se pudieron listar los modelos." >> "$LOG_FILE"
        fi
    else
        log "❌ No se pudo conectar con Ollama. Asegúrate de que el proxy esté corriendo." >> "$LOG_FILE"
    fi
    
    echo "" >> "$LOG_FILE"
}

# Función para verificar estado del grafo de memoria (opcional)
check_memory() {
    log "Verificando estado de la persistencia de datos..."
    
    if [ -f "${DATA_DIR}/memory_status.txt" ]; then
        local memory_status=$(cat "${DATA_DIR}/memory_status.txt")
        case "$memory_status" in
            *"initialized"*|*"ready"*)
                log "✅ Persistencia de datos lista." >> "$LOG_FILE"
                ;;
            *)
                log "⚠️ Estado desconocido para la persistencia. Se reinicializará si es necesario." >> "$LOG_FILE"
                ;;
        esac
    else
        # Crear archivo de estado inicial
        echo "initialized at $(date '+%d/%m/%Y %H:%M')" > "${DATA_DIR}/memory_status.txt"
        log "✅ Persistencia de datos inicializada." >> "$LOG_FILE"
    fi
    
    echo "" >> "$LOG_FILE"
}

# Función para verificar estado de PWAs (si hay archivos .desktop)
check_pwafs() {
    local desktop_dir="${SCRIPT_DIR}/../.."  # Escritorio del usuario
    log "Comprobando PWAs en el Escritorio..." >> "$LOG_FILE"
    
    if [ -d "$desktop_dir" ]; then
        local pwa_count=$(ls -1 "${desktop_dir}"/chrome-*.desktop 2>/dev/null | wc -l)
        
        if [ "$pwa_count" -gt 0 ]; then
            log "📱 Se encontraron $pwa_count archivo(s) PWA en el Escritorio." >> "$LOG_FILE"
            
            # Listar PWAs disponibles
            echo "" >> "$LOG_FILE"
            log "PWAs detectadas:" >> "$LOG_FILE"
            for pwa in "${desktop_dir}"/chrome-*.desktop; do
                if [ -f "$pwa" ]; then
                    local app_id=$(grep -oP 'chrome-[a-f0-9-]+-Profile_2\.desktop' <<< "$pwa" | cut -d: -f2)
                    log "   - $(basename "$app_id")" >> "$LOG_FILE"
                fi
            done
        else
            log "📱 No hay PWAs detectadas en el Escritorio." >> "$LOG_FILE"
        fi
    else
        log "⚠️ Directorio de Escritorio no encontrado o no accesible." >> "$LOG_FILE"
    fi
    
    echo "" >> "$LOG_FILE"
}

# Función para verificar credenciales y variables de entorno
check_env() {
    local env_file="${SCRIPT_DIR}/.env"
    
    if [ -f "$env_file" ]; then
        log "✅ Archivo .env existe." >> "$LOG_FILE"
        
        # Mostrar resumen (sin exponer valores sensibles)
        echo "" >> "$LOG_FILE"
        log "Variables de entorno configuradas:" >> "$LOG_FILE"
        grep -v '^#' "$env_file" | while IFS='=' read -r key value; do
            if [[ ! "$key" =~ ^SECRET_ ]] && [[ ! "$key" =~ ^API_KEY ]]; then
                log "   - $key (configurada)" >> "$LOG_FILE"
            fi
        done
        
    else
        log "⚠️ Archivo .env no encontrado. Se generará una plantilla." >> "$LOG_FILE"
        
        # Generar archivo .env por defecto
        cat > "$env_file" << 'EOF'
# Configuración de variables de entorno para OpenCode
# Copia este archivo a .env y edita con valores seguros

# --- Ollama ---
OLLAMA_API_KEY=ollama
OLLAMA_PROXY_PORT=4000

# --- Context7 ---
MCP_CONTEXT7_URL=https://mcp.context7.com/mcp

# --- PWAs (si necesitas cerrar/abrir) ---
CHROME_DEBUG_PROFILE=/tmp/chrome-debug-profile
REMOTE_DEBUGGING_PORT=9222

# --- Navegación web ---
USER_AGENT="Mozilla/5.0 (compatible; OpenCode-Bot)"
MAX_SEARCH_RESULTS=8

# ⚠️ NO COMENTAR ESTAS LÍNEAS PARA ACTIVAR CREDENCIALES SEGURAS:
# OLLAMA_API_KEY=tu_clave_segura_aqui
# EXTERNAL_SERVICE_API_KEY=tu_api_key_aqui

EOF
        
        chmod 600 "$env_file"
        log "✅ Archivo .env generado con valores por defecto." >> "$LOG_FILE"
    fi
    
    echo "" >> "$LOG_FILE"
}

# Función principal de inicialización
main() {
    log "=== INICIALIZACIÓN DE OPENCODE ==="
    
    # 1. Verificar proxy Ollama (IMPORTANTE)
    check_process "google-chrome.*remote-debugging-port|ollama-proxy" || true
    
    # Verificar específicamente el proxy Ollama
    if pgrep -f "ollama-proxy.py" > /dev/null 2>&1; then
        log "✅ Proxy Ollama (ollama-proxy.py) está ejecutándose."
    else
        log "ℹ️ El proxy Ollama no se está ejecutando. Asegúrate de iniciarlo con:" >> "$LOG_FILE"
        log '   python3 /home/antonio/.config/opencode/ollama-proxy.py 4000 > /tmp/ollama-proxy.log 2>&1 & disown' >> "$LOG_FILE"
    fi
    
    # 2. Verificar modelos disponibles
    check_models
    
    # 3. Verificar persistencia de datos (memoria)
    check_memory
    
    # 4. Comprobar PWAs en Escritorio
    check_pwafs
    
    # 5. Verificar variables de entorno
    check_env
    
    # Resumen final
    log "=== RESUMEN DE INICIALIZACIÓN ===" >> "$LOG_FILE"
    
    if [ -f "${DATA_DIR}/available_models.txt" ]; then
        local model_count=$(wc -l < "${DATA_DIR}/available_models.txt")
        log "📦 Total de modelos disponibles: $model_count" >> "$LOG_FILE"
    else
        log "⚠️ No se pudo determinar el número de modelos." >> "$LOG_FILE"
    fi
    
    if [ -f "${SCRIPT_DIR}/.env" ]; then
        log "✅ Configuración .env lista." >> "$LOG_FILE"
    fi
    
    echo "" >> "$LOG_FILE"
    log "=== INICIALIZACIÓN COMPLETADA ===" >> "$LOG_FILE"
    
    # Mostrar resumen en consola (últimas líneas del log)
    tail -20 "$LOG_FILE"
}

# Ejecutar inicialización
main

echo ""
echo "✅ Inicialización de OpenCode completada."
echo "📄 Ver detalles en: ${SCRIPT_DIR}/data/init.log"
