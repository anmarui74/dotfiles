#!/usr/bin/env bash
set -euo pipefail

# ============================================================
# Script de instalación completa: OpenCode + Ollama + Modelos + Proxy + Voz
# ============================================================
# Uso: bash setup-opencode-completo.sh
# ============================================================
# Fecha: 27/07/2026
# ¡TODO INCLUIDO! No requiere archivos externos.

DIR_CONFIG="$HOME/.config/opencode"
LOG_PROXY="/tmp/ollama-proxy.log"
DIR_DATA="$DIR_CONFIG/data"
DIR_MEMORY="$DIR_DATA/memory"
DIR_BACKUPS="$HOME/Config/opencode/backups"
LOCAL_BIN="$HOME/.local/bin"

# ─── Colores ────────────────────────────────────────────────
VERDE='\033[0;32m'; AMARILLO='\033[1;33m'; ROJO='\033[0;31m'; NC='\033[0m'
info()  { echo -e "${VERDE}[✓]${NC} $1"; }
warn()  { echo -e "${AMARILLO}[!]${NC} $1"; }
err()   { echo -e "${ROJO}[✗]${NC} $1"; }

echo "=============================================="
echo "  Instalación completa OpenCode + Ollama + Voz"
echo "=============================================="
echo ""

# ═══════════════════════════════════════════════════════════
# PASO 1: Instalar OpenCode
# ═══════════════════════════════════════════════════════════
echo "--- 1/14: Instalando OpenCode ---"
if command -v opencode &>/dev/null; then
    info "OpenCode ya instalado: $(opencode --version 2>/dev/null || echo 'desconocido')"
else
    curl -fsSL https://opencode.ai/install.sh | bash
    info "OpenCode instalado"
fi

# ═══════════════════════════════════════════════════════════
# PASO 2: Instalar Ollama
# ═══════════════════════════════════════════════════════════
echo "--- 2/14: Instalando Ollama ---"
if command -v ollama &>/dev/null; then
    info "Ollama ya instalado: $(ollama --version 2>/dev/null || echo 'desconocido')"
else
    curl -fsSL https://ollama.com/install.sh | sh
    info "Ollama instalado"
fi

# Asegurar que Ollama esté corriendo
if ! pgrep -f "ollama serve" &>/dev/null; then
    echo "  Arrancando Ollama..."
    ollama serve > /dev/null 2>&1 & disown
    sleep 3
fi
info "Ollama listo"

# ═══════════════════════════════════════════════════════════
# PASO 3: Descargar modelos
# ═══════════════════════════════════════════════════════════
echo "--- 3/14: Descargando modelos ---"

# Modelos a instalar
MODELOS=(
    "qwen3.5:9b"
    "qwen2.5-coder:7b"
    "gemma4:e4b"
    "llama3.1:8b"
    "deepseek-r1:8b"
    "deepseek-v4-flash-stock:latest"
)

for modelo in "${MODELOS[@]}"; do
    if curl -sf http://localhost:11434/api/tags 2>/dev/null | python3 -c "import json,sys; d=json.load(sys.stdin); exit(0 if any(m['name']==modelo for m in d.get('models',[])) else 1)" 2>/dev/null; then
        info "Modelo $modelo ya descargado"
    else
        echo "  Descargando $modelo (esto puede tardar)..."
        ollama pull "$modelo" 2>&1 | tail -1 || warn "Fallo al descargar $modelo"
    fi
done

# ═══════════════════════════════════════════════════════════
# PASO 4: Crear directorios
# ═══════════════════════════════════════════════════════════
echo "--- 4/14: Creando directorios ---"
mkdir -p "$DIR_CONFIG" "$DIR_CONFIG/prompts" "$DIR_DATA" "$DIR_MEMORY" "$DIR_BACKUPS" "$LOCAL_BIN"
info "Directorios creados"

# ═══════════════════════════════════════════════════════════
# PASO 5: opencode.json
# ═══════════════════════════════════════════════════════════
echo "--- 5/14: Configuración principal ---"
cat > "$DIR_CONFIG/opencode.json" << 'JSONEOF'

{
  "$schema": "https://opencode.ai/config.json",
  "instructions": [
    "AGENTS.md"
  ],
  "default_agent": "general",
  "small_model": "ollama/llama3.1:8b",
  "permission": {
    "edit": "ask",
    "bash": {
      "sudo *": "deny",
      "pkexec *": "allow",
      "*": "ask"
    }
  },
  "agent": {
    "build": {
      "prompt": "{file:./prompts/read-agents.txt}"
    },
    "plan": {
      "prompt": "{file:./prompts/read-agents.txt}"
    },
    "local": {
      "description": "Agente local con LM Studio",
      "mode": "primary",
      "model": "lmstudio/qwen/qwen3.5-9b"
    },
    "cloud": {
      "description": "Agente para modelos cloud",
      "mode": "primary",
      "model": "anthropic/claude-sonnet-4-20250514"
    }
  },
  "provider": {
    "lmstudio": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "LM Studio (local)",
      "model": "qwen/qwen3.5-9b",
      "options": {
        "baseURL": "http://127.0.0.1:4001/v1",
        "apiKey": "not-needed"
      },
      "models": {
        "qwen/qwen3.5-9b": {
          "name": "Qwen3.5 9B (LM Studio)",
          "tools": true
        },
        "google/gemma-4-e4b": {
          "name": "Gemma 4 E4B (LM Studio)",
          "tools": true
        },
        "deepseek/deepseek-r1-0528-qwen3-8b": {
          "name": "DeepSeek R1 8B (LM Studio)",
          "reasoning": true,
          "tools": true
        }
      }
    }
  },
  "mcp": {
    "context7": {
      "type": "remote",
      "url": "https://mcp.context7.com/mcp",
      "enabled": false
    },
    "filesystem": {
      "type": "local",
      "command": [
        "npx",
        "-y",
        "@modelcontextprotocol/server-filesystem",
        "/home/antonio"
      ],
      "enabled": true
    },
    "memory": {
      "type": "local",
      "command": [
        "npx",
        "-y",
        "@modelcontextprotocol/server-memory"
      ],
      "enabled": false
    },
    "fetch": {
      "type": "local",
      "command": [
        "npx",
        "-y",
        "mcp-fetch-server"
      ],
      "enabled": true
    },
    "sequential_thinking": {
      "type": "local",
      "command": [
        "npx",
        "-y",
        "@modelcontextprotocol/server-sequential-thinking"
      ],
      "enabled": false
    },
    "duckduckgo_search": {
      "type": "local",
      "command": [
        "duckduckgo-mcp-server"
      ],
      "enabled": false
    }
  }
}

JSONEOF
info "opencode.json creado"

# ─── Perfiles local/cloud ──────────────────────────────
cat > "$DIR_CONFIG/opencode-local.json" << 'LOCALEOF'

{
  "$schema": "https://opencode.ai/config.json",
  "instructions": [
    "AGENTS.md"
  ],
  "default_agent": "general",
  "small_model": "ollama/llama3.1:8b",
  "permission": {
    "edit": "ask",
    "bash": {
      "sudo *": "deny",
      "pkexec *": "allow",
      "*": "ask"
    }
  },
  "agent": {
    "build": {
      "prompt": "{file:./prompts/read-agents.txt}"
    },
    "plan": {
      "prompt": "{file:./prompts/read-agents.txt}"
    },
    "local": {
      "description": "Agente local con LM Studio",
      "mode": "primary",
      "model": "lmstudio/qwen/qwen3.5-9b"
    },
    "cloud": {
      "description": "Agente para modelos cloud",
      "mode": "primary",
      "model": "anthropic/claude-sonnet-4-20250514"
    }
  },
  "provider": {
    "lmstudio": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "LM Studio (local)",
      "model": "qwen/qwen3.5-9b",
      "options": {
        "baseURL": "http://127.0.0.1:4001/v1",
        "apiKey": "not-needed"
      },
      "models": {
        "qwen/qwen3.5-9b": {
          "name": "Qwen3.5 9B (LM Studio)",
          "tools": true
        },
        "google/gemma-4-e4b": {
          "name": "Gemma 4 E4B (LM Studio)",
          "tools": true
        },
        "deepseek/deepseek-r1-0528-qwen3-8b": {
          "name": "DeepSeek R1 8B (LM Studio)",
          "reasoning": true,
          "tools": true
        }
      }
    }
  },
  "mcp": {
    "context7": {
      "type": "remote",
      "url": "https://mcp.context7.com/mcp",
      "enabled": false
    },
    "filesystem": {
      "type": "local",
      "command": [
        "npx",
        "-y",
        "@modelcontextprotocol/server-filesystem",
        "/home/antonio"
      ],
      "enabled": true
    },
    "memory": {
      "type": "local",
      "command": [
        "npx",
        "-y",
        "@modelcontextprotocol/server-memory"
      ],
      "enabled": false
    },
    "fetch": {
      "type": "local",
      "command": [
        "npx",
        "-y",
        "mcp-fetch-server"
      ],
      "enabled": true
    },
    "sequential_thinking": {
      "type": "local",
      "command": [
        "npx",
        "-y",
        "@modelcontextprotocol/server-sequential-thinking"
      ],
      "enabled": false
    },
    "duckduckgo_search": {
      "type": "local",
      "command": [
        "duckduckgo-mcp-server"
      ],
      "enabled": false
    }
  }
}

LOCALEOF
info "opencode-local.json creado"

cat > "$DIR_CONFIG/opencode-cloud.json" << 'CLOUDEOF'

{
  "$schema": "https://opencode.ai/config.json",
  "instructions": [
    "AGENTS.md"
  ],
  "default_agent": "general",
  "small_model": "ollama/llama3.1:8b",
  "permission": {
    "edit": "ask",
    "bash": {
      "sudo *": "deny",
      "pkexec *": "allow",
      "*": "ask"
    }
  },
  "agent": {
    "build": {
      "prompt": "{file:./prompts/read-agents.txt}"
    },
    "plan": {
      "prompt": "{file:./prompts/read-agents.txt}"
    },
    "local": {
      "description": "Agente local con LM Studio",
      "mode": "primary",
      "model": "lmstudio/qwen/qwen3.5-9b"
    },
    "cloud": {
      "description": "Agente para modelos cloud",
      "mode": "primary",
      "model": "anthropic/claude-sonnet-4-20250514"
    }
  },
  "provider": {
    "lmstudio": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "LM Studio (local)",
      "model": "qwen/qwen3.5-9b",
      "options": {
        "baseURL": "http://127.0.0.1:4001/v1",
        "apiKey": "not-needed"
      },
      "models": {
        "qwen/qwen3.5-9b": {
          "name": "Qwen3.5 9B (LM Studio)",
          "tools": true
        },
        "google/gemma-4-e4b": {
          "name": "Gemma 4 E4B (LM Studio)",
          "tools": true
        },
        "deepseek/deepseek-r1-0528-qwen3-8b": {
          "name": "DeepSeek R1 8B (LM Studio)",
          "reasoning": true,
          "tools": true
        }
      }
    }
  },
  "mcp": {
    "context7": {
      "type": "remote",
      "url": "https://mcp.context7.com/mcp",
      "enabled": true
    },
    "filesystem": {
      "type": "local",
      "command": [
        "npx",
        "-y",
        "@modelcontextprotocol/server-filesystem",
        "/home/antonio"
      ],
      "enabled": true
    },
    "memory": {
      "type": "local",
      "command": [
        "npx",
        "-y",
        "@modelcontextprotocol/server-memory"
      ],
      "enabled": true
    },
    "fetch": {
      "type": "local",
      "command": [
        "npx",
        "-y",
        "mcp-fetch-server"
      ],
      "enabled": true
    },
    "sequential_thinking": {
      "type": "local",
      "command": [
        "npx",
        "-y",
        "@modelcontextprotocol/server-sequential-thinking"
      ],
      "enabled": true
    },
    "duckduckgo_search": {
      "type": "local",
      "command": [
        "duckduckgo-mcp-server"
      ],
      "enabled": true
    }
  }
}

CLOUDEOF
info "opencode-cloud.json creado"

cat > "$DIR_CONFIG/switch-mcp-profile.sh" << 'SWITCHEOF'
{switch_profile}
SWITCHEOF
chmod +x "$DIR_CONFIG/switch-mcp-profile.sh"
info "switch-mcp-profile.sh creado"

# ─── sync-opencode.sh (vigilante automático) ─────────
cat > "$DIR_CONFIG/sync-opencode.sh" << 'SYNCEOF'
{sync_content}
SYNCEOF
chmod +x "$DIR_CONFIG/sync-opencode.sh"
info "sync-opencode.sh creado"

# ─── Servicio systemd de sincronización ──────────────
mkdir -p "$HOME/.config/systemd/user"
cat > "$HOME/.config/systemd/user/opencode-sync.service" << 'SYSEOF'
[Unit]
Description=OpenCode sync: .config/opencode -> Config/opencode + backup
After=network.target

[Service]
Type=oneshot
ExecStart=/home/antonio/.config/opencode/sync-opencode.sh
StandardOutput=journal
StandardError=journal
SYSEOF

cat > "$HOME/.config/systemd/user/opencode-sync.timer" << 'TIMEREOF'
[Unit]
Description=Sync OpenCode config every 2 minutes

[Timer]
OnBootSec=1min
OnUnitActiveSec=2min
Unit=opencode-sync.service

[Install]
WantedBy=default.target
TIMEREOF

systemctl --user daemon-reload 2>/dev/null || true
systemctl --user enable opencode-sync.timer 2>/dev/null || true
systemctl --user start opencode-sync.timer 2>/dev/null || true
info "Timer de sincronización activado (cada 2 min)"

# ═══════════════════════════════════════════════════════════
# PASO 6: AGENTS.md
# ═══════════════════════════════════════════════════════════
echo "--- 6/14: Reglas del asistente ---"
cat > "$DIR_CONFIG/AGENTS.md" << 'AGEOF'

# REGLAS OBLIGATORIAS (APLICAR SIEMPRE)

## Usuario
- Se llama Antonio
- Vive en Pechina (Almería, España)

## Idioma
- Responde SIEMPRE en español
- NUNCA cambies al inglés (salvo petición expresa de traducción)
- Español de España (no latinoamericano)

## Formato
- SÍ usamos emoji en pantalla (✈️ 🌤️ 😊) para expresividad visual 
- Mi locucionero filtra estos iconos automáticamente antes del TTS, sin necesidad de configuración extra
- Fecha: dd/mm/aaaa
- Hora: formato 24h (14:30, no 2:30pm)
- Decimales: coma (3,14 no 3.14)
- Moneda: euros (€)
- Sistema métrico: km/h, °C, mm, km

## 🌤️ Consultar el tiempo (IMPORTANTE)
Para preguntas sobre el tiempo, usa la herramienta fetch_html (o fetch_json) para consultar:
https://wttr.in/{ciudad}?format=j1&m&lang=es
Ejemplo: https://wttr.in/Pechina?format=j1&m&lang=es

⚠️ Si wttr.in no responde o devuelve vacío, NO vuelvas a llamar a fetch.
Limítate a informar al usuario: "wttr.in no está disponible ahora, inténtalo más tarde."

## 🔧 Uso de herramientas (OBLIGATORIO)
Cuando tengas que hacer una tarea que requiera una herramienta (leer archivos,
listar directorios, ejecutar comandos, etc.) USA LA HERRAMIENTA directamente.
NO describas lo que harías — hazlo.
NO digas "voy a leer" sin llamar a la herramienta.
NO generes texto explicando los pasos sin ejecutarlos.
SIMPLIFICA: si necesitas leer múltiples archivos, usa search_files con un
patrón, o llama a read_file para cada archivo individual.

## 🛠️ Elevación de privilegios (sudo NO)
- NUNCA uses `sudo` para comandos que requieran contraseña
- Usa SIEMPRE `pkexec` en su lugar: así saldrá una ventana gráfica pidiendo la contraseña
- Ejemplo: `pkexec apt update` en vez de `sudo apt update`

---

# PROCEDIMIENTOS TÉCNICOS

## Sincronización con Config/opencode (OBLIGATORIO)
- `~/.config/opencode/` es la configuración ACTIVA (la que usa OpenCode)
- `~/Config/opencode/` es la copia de SEGURIDAD para instalaciones desde limpio
- Cada vez que modifiques, crees o elimines algo en `~/.config/opencode/`:
  1. **Copia el archivo** a `~/Config/opencode/` (manteniendo la misma estructura)
  2. **Actualiza los scripts** de instalación si es necesario:
     - `~/Config/opencode/backup-opencode.sh` → script que empaqueta el backup
     - `~/Config/opencode/bootstrap-ocv.sh` → script de instalación desde limpio
     - `restore.sh` (va dentro del tarball, lo genera backup-opencode.sh)
  3. Si el cambio afecta al proceso de instalación/restauración, modifica los scripts para reflejarlo
- Ejecuta `bash ~/Config/opencode/backup-opencode.sh` para regenerar el tarball con restore.sh actualizado

---

# PERSISTENCIA DE DATOS Y RECUPERACIÓN

## Variables de entorno
El archivo `.env` contiene la configuración sensible. Para cargarlo:
```bash
set -a; source /home/antonio/.config/opencode/.env; set +a
```

## Inicialización (tras reinicio del sistema)
Ejecutar el script de inicialización que verifica todos los componentes:
```bash
bash /home/antonio/.config/opencode/init-opencode.sh
```
Esto comprueba:
- Proxy Ollama (puerto 4000)
- Modelos disponibles en Ollama
- Persistencia del grafo de memoria
- PWAs en el Escritorio
- Variables de entorno (.env)

## Backup automático del grafo de memoria
El grafo de conocimiento se respalda automáticamente en:
`/home/antonio/Config/opencode/backups/`
Con nombre `mcp-memory-backup-{fecha}.json`
Los backups se conservan 30 días (según LOG_RETENTION_DAYS en .env)

## Recuperación del grafo de memoria
Si el grafo se pierde o corrompe:
1. Localizar el backup más reciente:
   ```bash
   ls -t /home/antonio/Config/opencode/backups/mcp-memory-backup-*.json | head -1
   ```
2. El servidor MCP Memory debería restaurarlo automáticamente al iniciar desde `MEMORY_DATA_DIR`

## Directorios de datos
- `/home/antonio/.config/opencode/data/` - Datos de ejecución (logs, estado)
- `/home/antonio/.config/opencode/data/memory/` - Grafo de memoria persistente
- `/home/antonio/Config/opencode/backups/` - Copias de seguridad del grafo
- `/home/antonio/.config/opencode/.env` - Variables de entorno seguras

---

# AVANZADO (uso principalmente con DeepSeek)

## PWAs - Cómo abrir
1. Leer /home/antonio/Escritorio
2. Buscar archivo chrome-<app-id>-Profile_2.desktop
3. Ejecutar línea Exec= del archivo

## PWAs - Cerrar
- Una PWA: curl -s http://localhost:9222/json/close/<ID>
- Todo Chrome: pkill -f "chrome.*remote-debugging-port"

## Chrome debug (si no está corriendo)
nohup /opt/google/chrome/google-chrome --user-data-dir="/tmp/chrome-debug-profile" "--profile-directory=DebugProfile" --remote-debugging-port=9222 "--remote-allow-origins=*" about:blank > /dev/null 2>&1 &

## Proxy Ollama (obligatorio para conexión local)
python3 /home/antonio/.config/opencode/ollama-proxy.py 4000 > /tmp/ollama-proxy.log 2>&1 & disown

## Liberar VRAM (sin descargar el modelo)
El modelo se mantiene cargado en VRAM 10 minutos tras cada uso gracias al keep_alive.
NO se descarga automáticamente tras cada respuesta para evitar recargas constantes.
Si el modelo se satura (generaciones muy largas o error), pide a OpenCode que lo haga:
"Dime: Libera la VRAM"
OpenCode ejecutará: ollama stop qwen3.5:9b
Esto libera la KV cache acumulada. El modelo se recargará solo en la siguiente petición.

---

# CHECKLIST ANTES DE RESPONDER
- ¿Respuesta en español?
- ¿Fecha/hora en formato España?
- ¿Decimales con coma?
- Si pregunta por el tiempo: ¿he usado wttr.in?
- ¿He usado la herramienta directamente en vez de describir lo que haría?

AGEOF
info "AGENTS.md creado"

# ═══════════════════════════════════════════════════════════
# PASO 7: Prompts
# ═══════════════════════════════════════════════════════════
echo "--- 7/14: Prompts ---"
cat > "$DIR_CONFIG/prompts/read-agents.txt" << 'PROMPTEOF'
Al inicio de cada sesión, usa la herramienta Read para leer ~/.config/opencode/AGENTS.md y seguir las instrucciones del usuario.
PROMPTEOF
info "Prompts creados"

# ═══════════════════════════════════════════════════════════
# PASO 8: Proxy Ollama (con parche de tools #34892)
# ═══════════════════════════════════════════════════════════
echo "--- 8/14: Proxy Ollama ---"
cat > "$DIR_CONFIG/ollama-proxy.py" << 'PYEOF'
#!/usr/bin/env python3
"""Proxy OpenCode ↔ Ollama: no-streaming interno, inyección de tools.
Parchea bug #34892: @ai-sdk/openai-compatible serializa tools con function.name=undefined.
"""
import json, http.server, urllib.request, sys, time, uuid, threading, subprocess, re, os

OLLAMA_BASE = "http://localhost:11434"
NUM_CTX_DEFAULT = 16384
NUM_PREDICT_DEFAULT = 8192
VRAM_THRESHOLD = 75
CHECK_INTERVAL = 2

# ── Tools de OpenCode (fallback para sortear bug #34892) ──
FALLBACK_TOOLS = [
    {"type":"function","function":{"name":"read","description":"Read file contents.","parameters":{"type":"object","properties":{"filePath":{"type":"string","description":"Absolute path."}},"required":["filePath"]}}},
    {"type":"function","function":{"name":"write","description":"Create or overwrite a file.","parameters":{"type":"object","properties":{"filePath":{"type":"string"},"content":{"type":"string"}},"required":["filePath","content"]}}},
    {"type":"function","function":{"name":"edit","description":"Replace exact text in a file.","parameters":{"type":"object","properties":{"filePath":{"type":"string"},"oldString":{"type":"string"},"newString":{"type":"string"}},"required":["filePath","oldString","newString"]}}},
    {"type":"function","function":{"name":"bash","description":"Execute a shell command.","parameters":{"type":"object","properties":{"command":{"type":"string"}},"required":["command"]}}},
    {"type":"function","function":{"name":"grep","description":"Search file contents with regex.","parameters":{"type":"object","properties":{"pattern":{"type":"string"},"path":{"type":"string"},"include":{"type":"string"}},"required":["pattern"]}}},
    {"type":"function","function":{"name":"glob","description":"Find files by glob pattern.","parameters":{"type":"object","properties":{"pattern":{"type":"string"},"path":{"type":"string"}},"required":["pattern"]}}},
    {"type":"function","function":{"name":"list_files","description":"List a directory.","parameters":{"type":"object","properties":{"path":{"type":"string"}},"required":["path"]}}},
    {"type":"function","function":{"name":"task","description":"Launch a sub-agent.","parameters":{"type":"object","properties":{"description":{"type":"string"},"prompt":{"type":"string"},"subagent_type":{"type":"string"}},"required":["description","prompt"]}}},
    {"type":"function","function":{"name":"todowrite","description":"Update task list.","parameters":{"type":"object","properties":{"todos":{"type":"array","items":{"type":"object","properties":{"content":{"type":"string"},"status":{"type":"string"},"priority":{"type":"string"}}}},"description":{"type":"string"}},"required":["todos"]}}},
    {"type":"function","function":{"name":"question","description":"Ask the user.","parameters":{"type":"object","properties":{"questions":{"type":"array","items":{"type":"object","properties":{"question":{"type":"string"},"header":{"type":"string"},"options":{"type":"array"}}}},"description":{"type":"string"}},"required":["questions"]}}},
    {"type":"function","function":{"name":"fetch","description":"Fetch a URL.","parameters":{"type":"object","properties":{"url":{"type":"string"}},"required":["url"]}}},
    {"type":"function","function":{"name":"websearch","description":"Search the web.","parameters":{"type":"object","properties":{"query":{"type":"string"},"numResults":{"type":"number"}},"required":["query"]}}},
    {"type":"function","function":{"name":"search_files","description":"Recursively search files.","parameters":{"type":"object","properties":{"pattern":{"type":"string"},"path":{"type":"string"}},"required":["pattern","path"]}}},
]

_tools_cache = list(FALLBACK_TOOLS)
_has_mcp_tools = False

def _try_discover_mcp():
    """Intenta descubrir herramientas de MCP servers (opcional)."""
    global _tools_cache, _has_mcp_tools
    discovered = []
    servers = [
        ("npx", "-y", "@modelcontextprotocol/server-filesystem", os.path.expanduser("~")),
    ]
    for cmd_parts in servers:
        try:
            proc = subprocess.Popen(
                list(cmd_parts), stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
            )
            req = json.dumps({"jsonrpc":"2.0","id":1,"method":"tools/list"})
            out, _ = proc.communicate(input=req, timeout=15)
            if out:
                result = json.loads(out)
                for tool in result.get("result",{}).get("tools",[]):
                    discovered.append({
                        "type":"function",
                        "function":{
                            "name": tool["name"],
                            "description": tool.get("description",""),
                            "parameters": tool.get("inputSchema",{"type":"object","properties":{}}),
                        }
                    })
        except Exception:
            pass

    if discovered:
        seen = {t["function"]["name"] for t in FALLBACK_TOOLS}
        for t in discovered:
            if t["function"]["name"] not in seen:
                _tools_cache.append(t)
                seen.add(t["function"]["name"])
        _has_mcp_tools = True
        print(f"[proxy] +{len(discovered)} MCP tools descubiertas", flush=True)

    print(f"[proxy] Tools cargadas: {len(_tools_cache)} ({len(FALLBACK_TOOLS)} fallback + {len(discovered)} MCP)", flush=True)

# Lanzar descubrimiento MCP en bg al importar
threading.Thread(target=_try_discover_mcp, daemon=True).start()

# ── Gestión VRAM ──
_resp_counter = {}
_counter_lock = threading.Lock()

def _get_vram_usage() -> float:
    try:
        r = subprocess.run(["nvidia-smi","--query-gpu=memory.used,memory.total","--format=csv,noheader,nounits"],
                          capture_output=True, text=True, timeout=5)
        if r.returncode != 0: return 0.0
        parts = r.stdout.strip().split(",")
        if len(parts) >= 2:
            used, total = float(parts[0].strip()), float(parts[1].strip())
            return (used/total)*100 if total > 0 else 0.0
    except: pass
    return 0.0

def _cleanup_model(model):
    try:
        req = urllib.request.Request(f"{OLLAMA_BASE}/api/generate",
            data=json.dumps({"model":model,"prompt":"","keep_alive":0}).encode(),
            headers={"Content-Type":"application/json"})
        with urllib.request.urlopen(req, timeout=10): pass
        print(f"[proxy] KV cache liberada para {model}", flush=True)
    except: pass

def _check_vram_and_clean(model):
    vram = _get_vram_usage()
    if vram <= 0: return
    if vram >= VRAM_THRESHOLD:
        print(f"[proxy] VRAM {vram:.0f}% > {VRAM_THRESHOLD}% -> limpiando {model}", flush=True)
        _cleanup_model(model)

# ── Normalizar mensajes ──
def _normalize_messages(messages):
    for m in messages:
        c = m.get("content")
        if isinstance(c, list):
            texts = []
            for part in c:
                if isinstance(part, dict):
                    t = part.get("type")
                    if t == "text": texts.append(part.get("text",""))
                    elif t == "tool_result": texts.append(str(part.get("content","")))
                    else: texts.append(str(part.get("text","") or ""))
                else: texts.append(str(part))
            m["content"] = "\n".join(texts) if texts else ""
        tc = m.get("tool_calls")
        if tc:
            for t in tc:
                func = t.get("function",{})
                args = func.get("arguments")
                if isinstance(args, str):
                    try: func["arguments"] = json.loads(args)
                    except: pass

# ── Proxy HTTP ──
class Proxy(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"
    def _json(self, data, code=200):
        self.send_response(code)
        self.send_header("Content-Type","application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode())
    def _sse(self, data):
        self.wfile.write(f"data: {json.dumps(data, ensure_ascii=False)}\n\n".encode())
        self.wfile.flush()

    def do_GET(self):
        if self.path in ("/v1/models","/models"):
            req = urllib.request.Request(f"{OLLAMA_BASE}/api/tags")
            with urllib.request.urlopen(req) as r:
                data = json.load(r)
            models = {"object":"list","data":[]}
            for m in data.get("models",[]):
                models["data"].append({"id":m["name"],"object":"model"})
            self._json(models)
        else:
            self._json({"error":"not found"},404)

    def do_POST(self):
        path = self.path
        if "/v1/responses" in path: path = "/v1/chat/completions"
        if "/chat/completions" not in path:
            return self._json({"error":"not found"},404)
        self._handle()

    def _handle(self):
        raw = self.rfile.read(int(self.headers.get("Content-Length",0)))
        body = json.loads(raw)
        model = body.get("model","")
        want_stream = body.get("stream",False)
        messages = body.get("messages",[])

        # ═══ WORKAROUND: Inyectar tools si OpenCode las envía rotas ═══
        raw_tools = body.get("tools")
        needs_injection = False
        reason = ""

        if "tools" not in body:
            needs_injection = True
            reason = "no envió tools"
        elif isinstance(raw_tools, list):
            if len(raw_tools) == 0:
                needs_injection = True
                reason = "envió tools vacías"
            else:
                # Detectar bug #34892: function.name undefined
                for t in raw_tools:
                    fn = t.get("function",{})
                    if not fn.get("name"):
                        needs_injection = True
                        reason = "tools con function.name vacío (bug #34892)"
                        break

        if needs_injection:
            body["tools"] = _tools_cache
            print(f"[proxy] ⚡ WORKAROUND ({reason}) -> inyectadas {len(_tools_cache)} tools", flush=True)

        _normalize_messages(messages)

        ctx = body.get("options",{}).get("num_ctx") or NUM_CTX_DEFAULT
        np = min(body.get("max_tokens", NUM_PREDICT_DEFAULT), 8192)

        ollama_body = {
            "model": model, "stream": False,
            "messages": messages, "keep_alive": "10m",
            "options": {"num_ctx": ctx, "num_predict": np},
        }
        final_tools = body.get("tools")
        if final_tools and isinstance(final_tools, list) and len(final_tools) > 0:
            ollama_body["tools"] = final_tools
            # NO forzamos reasoning_effort=none para no bloquear modelos con razonamiento

        print(f"[proxy] model={model} tools={'yes' if ollama_body.get('tools') else 'no'} stream={want_stream} msgs={len(messages)} ctx={ctx}", flush=True)

        try:
            req_str = json.dumps(ollama_body, ensure_ascii=False)
            req = urllib.request.Request(f"{OLLAMA_BASE}/api/chat",
                data=req_str.encode(), headers={"Content-Type":"application/json"})
            with urllib.request.urlopen(req, timeout=600) as r:
                result = json.load(r)
        except urllib.error.HTTPError as e:
            err = e.read().decode("utf-8",errors="replace")[:500]
            print(f"[proxy] HTTP {e.code}: {err}", flush=True, file=sys.stderr)
            fname = f"/tmp/proxy-error-{uuid.uuid4().hex[:8]}.json"
            with open(fname,"w") as f: f.write(req_str)
            print(f"[proxy] Body guardado en {fname}", flush=True)
            return self._json({"error":f"HTTP {e.code}: {err}"},502)
        except Exception as e:
            print(f"[proxy] Error: {e}", flush=True, file=sys.stderr)
            return self._json({"error":str(e)},500)

        msg = result.get("message",{})
        content = msg.get("content") or ""
        thinking = msg.get("thinking") or ""
        tc = msg.get("tool_calls")

        if not content and not tc and thinking:
            content = thinking
        if tc and thinking and not content:
            content = thinking

        tool_calls = None
        if tc:
            tool_calls = [
                {"id": t.get("id",f"call_{i}"), "type":"function",
                 "function":{"name":t["function"]["name"], "arguments":json.dumps(t["function"]["arguments"])}}
                for i,t in enumerate(tc)
            ]

        _check_vram_and_clean(model)
        with _counter_lock:
            _resp_counter[model] = _resp_counter.get(model,0) + 1
            if _resp_counter[model] >= CHECK_INTERVAL:
                _resp_counter[model] = 0
                threading.Thread(target=_check_vram_and_clean, args=(model,), daemon=True).start()

        if want_stream:
            self._send_stream(model, content, tool_calls)
        else:
            self._send_single(model, content, tool_calls)

    def _send_single(self, model, content, tool_calls):
        choice = {"index":0, "message":{"role":"assistant","content":content},
                  "finish_reason":"tool_calls" if tool_calls else "stop"}
        if tool_calls:
            choice["message"]["tool_calls"] = tool_calls
        self._json({"id":"chatcmpl-1","object":"chat.completion","choices":[choice],"model":model})

    def _send_stream(self, model, content, tool_calls):
        self.close_connection = True
        self.send_response(200)
        self.send_header("Content-Type","text/event-stream")
        self.send_header("Cache-Control","no-cache")
        self.end_headers()
        self.wfile.flush()
        try:
            if tool_calls:
                # Enviar thinking como contenido primero (si existe)
                if content:
                    for i in range(0, len(content), 40):
                        self._sse({"id":"chatcmpl-1","object":"chat.completion.chunk","choices":[{
                            "index":0,"delta":{"content":content[i:i+40]},"finish_reason":None}],"model":model})
                        time.sleep(0.003)
                    # Chunk separador antes de tool_calls
                    self._sse({"id":"chatcmpl-1","object":"chat.completion.chunk","choices":[{
                        "index":0,"delta":{"content":""},"finish_reason":None}],"model":model})
                for i, tc in enumerate(tool_calls):
                    # Chunk nombre
                    self._sse({"id":"chatcmpl-1","object":"chat.completion.chunk","choices":[{
                        "index":0, "delta":{"role":"assistant","content":null,"tool_calls":[{
                            "index":i, "id":tc.get("id",f"call_{i}"), "type":"function",
                            "function":{"name":tc["function"]["name"],"arguments":""}
                        }]}, "finish_reason":None
                    }],"model":model})
                    # Chunk argumentos
                    self._sse({"id":"chatcmpl-1","object":"chat.completion.chunk","choices":[{
                        "index":0, "delta":{"tool_calls":[{"index":i,"function":{"arguments":tc["function"]["arguments"]}}]},
                        "finish_reason":None
                    }],"model":model})
                # Final
                self._sse({"id":"chatcmpl-1","object":"chat.completion.chunk","choices":[{
                    "index":0,"delta":{},"finish_reason":"tool_calls"}],"model":model})
            else:
                content = content or ""
                for i in range(0, len(content), 20):
                    self._sse({"id":"chatcmpl-1","object":"chat.completion.chunk","choices":[{
                        "index":0,"delta":{"content":content[i:i+20]},"finish_reason":None}],"model":model})
                    time.sleep(0.005)
                self._sse({"id":"chatcmpl-1","object":"chat.completion.chunk","choices":[{
                    "index":0,"delta":{},"finish_reason":"stop"}],"model":model})
        except: pass
        try:
            self.wfile.write(b"data: [DONE]\n\n"); self.wfile.flush()
        except: pass
        try: self.connection.shutdown(__import__("socket").SHUT_WR)
        except: pass

if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 4000
    server = http.server.ThreadingHTTPServer(("127.0.0.1", port), Proxy)
    print(f"Proxy en http://127.0.0.1:{port}", flush=True)
    print(f"Tools: {len(_tools_cache)} ({'con MCP' if _has_mcp_tools else 'solo fallback'})", flush=True)
    server.serve_forever()

PYEOF
chmod +x "$DIR_CONFIG/ollama-proxy.py"
info "Proxy creado y con permisos"

# ═══════════════════════════════════════════════════════════
# PASO 9: init-opencode.sh
# ═══════════════════════════════════════════════════════════
echo "--- 9/14: Script de inicialización ---"
cat > "$DIR_CONFIG/init-opencode.sh" << 'INITEOF'
#!/bin/bash
# Script de inicialización de OpenCode
# Verifica componentes y estado del sistema

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${SCRIPT_DIR}/opencode.json"
LOG_FILE="${SCRIPT_DIR}/data/init.log"
DATA_DIR="${SCRIPT_DIR}/data"

# Crear directorio de datos si no existe
mkdir -p "$DATA_DIR"

# Inicializar log de inicialización
echo "=== Inicialización OpenCode - $(date '+%d/%m/%Y %H:%M') ===" > "$LOG_FILE"
echo "" >> "$LOG_FILE"

log() {
    echo "[$(date '+%H:%M')] $1" | tee -a "$LOG_FILE"
}

# Función para verificar si un proceso está corriendo
check_process() {
    local process_name=$1
    if pgrep -f "$process_name" > /dev/null 2>&1; then
        log "✅ El proceso '$process_name' ya está ejecutándose."
        return 0
    else
        log "❌ El proceso '$process_name' NO está ejecutándose."
        return 1
    fi
}

# Función para verificar disponibilidad de modelos Ollama
check_models() {
    local port=${OLLAMA_PROXY_PORT:-4000}
    log "" >> "$LOG_FILE"
    log "Verificando conexión con Ollama (puerto $port)..."
    
    # Esperar un momento por si el servicio está iniciándose
    sleep 2
    
    if curl -s http://localhost:${port}/api/tags > /dev/null 2>&1; then
        log "✅ Conexión a Ollama establecida."
        
        # Listar modelos disponibles
        local models_response=$(curl -s http://localhost:${port}/api/tags)
        echo "$models_response" | grep -o '"name":"[^"]*"' | cut -d'"' -f4 > "${DATA_DIR}/available_models.txt" 2>/dev/null || true
        
        if [ -f "${DATA_DIR}/available_models.txt" ]; then
            log "📦 Modelos disponibles:" >> "$LOG_FILE"
            while IFS= read -r model; do
                log "   - $model" >> "$LOG_FILE"
            done < "${DATA_DIR}/available_models.txt"
        else
            log "⚠️ No se pudieron listar los modelos." >> "$LOG_FILE"
        fi
    else
        log "❌ No se pudo conectar con Ollama. Asegúrate de que el proxy esté corriendo." >> "$LOG_FILE"
    fi
    
    echo "" >> "$LOG_FILE"
}

# Función para verificar estado del grafo de memoria (opcional)
check_memory() {
    log "Verificando estado de la persistencia de datos..."
    
    if [ -f "${DATA_DIR}/memory_status.txt" ]; then
        local memory_status=$(cat "${DATA_DIR}/memory_status.txt")
        case "$memory_status" in
            *"initialized"*|*"ready"*)
                log "✅ Persistencia de datos lista." >> "$LOG_FILE"
                ;;
            *)
                log "⚠️ Estado desconocido para la persistencia. Se reinicializará si es necesario." >> "$LOG_FILE"
                ;;
        esac
    else
        # Crear archivo de estado inicial
        echo "initialized at $(date '+%d/%m/%Y %H:%M')" > "${DATA_DIR}/memory_status.txt"
        log "✅ Persistencia de datos inicializada." >> "$LOG_FILE"
    fi
    
    echo "" >> "$LOG_FILE"
}

# Función para verificar estado de PWAs (si hay archivos .desktop)
check_pwafs() {
    local desktop_dir="${SCRIPT_DIR}/../.."  # Escritorio del usuario
    log "Comprobando PWAs en el Escritorio..." >> "$LOG_FILE"
    
    if [ -d "$desktop_dir" ]; then
        local pwa_count=$(ls -1 "${desktop_dir}"/chrome-*.desktop 2>/dev/null | wc -l)
        
        if [ "$pwa_count" -gt 0 ]; then
            log "📱 Se encontraron $pwa_count archivo(s) PWA en el Escritorio." >> "$LOG_FILE"
            
            # Listar PWAs disponibles
            echo "" >> "$LOG_FILE"
            log "PWAs detectadas:" >> "$LOG_FILE"
            for pwa in "${desktop_dir}"/chrome-*.desktop; do
                if [ -f "$pwa" ]; then
                    local app_id=$(grep -oP 'chrome-[a-f0-9-]+-Profile_2\.desktop' <<< "$pwa" | cut -d: -f2)
                    log "   - $(basename "$app_id")" >> "$LOG_FILE"
                fi
            done
        else
            log "📱 No hay PWAs detectadas en el Escritorio." >> "$LOG_FILE"
        fi
    else
        log "⚠️ Directorio de Escritorio no encontrado o no accesible." >> "$LOG_FILE"
    fi
    
    echo "" >> "$LOG_FILE"
}

# Función para verificar credenciales y variables de entorno
check_env() {
    local env_file="${SCRIPT_DIR}/.env"
    
    if [ -f "$env_file" ]; then
        log "✅ Archivo .env existe." >> "$LOG_FILE"
        
        # Mostrar resumen (sin exponer valores sensibles)
        echo "" >> "$LOG_FILE"
        log "Variables de entorno configuradas:" >> "$LOG_FILE"
        grep -v '^#' "$env_file" | while IFS='=' read -r key value; do
            if [[ ! "$key" =~ ^SECRET_ ]] && [[ ! "$key" =~ ^API_KEY ]]; then
                log "   - $key (configurada)" >> "$LOG_FILE"
            fi
        done
        
    else
        log "⚠️ Archivo .env no encontrado. Se generará una plantilla." >> "$LOG_FILE"
        
        # Generar archivo .env por defecto
        cat > "$env_file" << 'EOF'
# Configuración de variables de entorno para OpenCode
# Copia este archivo a .env y edita con valores seguros

# --- Ollama ---
OLLAMA_API_KEY=ollama
OLLAMA_PROXY_PORT=4000

# --- Context7 ---
MCP_CONTEXT7_URL=https://mcp.context7.com/mcp

# --- PWAs (si necesitas cerrar/abrir) ---
CHROME_DEBUG_PROFILE=/tmp/chrome-debug-profile
REMOTE_DEBUGGING_PORT=9222

# --- Navegación web ---
USER_AGENT="Mozilla/5.0 (compatible; OpenCode-Bot)"
MAX_SEARCH_RESULTS=8

# ⚠️ NO COMENTAR ESTAS LÍNEAS PARA ACTIVAR CREDENCIALES SEGURAS:
# OLLAMA_API_KEY=tu_clave_segura_aqui
# EXTERNAL_SERVICE_API_KEY=tu_api_key_aqui

EOF
        
        chmod 600 "$env_file"
        log "✅ Archivo .env generado con valores por defecto." >> "$LOG_FILE"
    fi
    
    echo "" >> "$LOG_FILE"
}

# Función principal de inicialización
main() {
    log "=== INICIALIZACIÓN DE OPENCODE ==="
    
    # 1. Verificar proxy Ollama (IMPORTANTE)
    check_process "google-chrome.*remote-debugging-port|ollama-proxy" || true
    
    # Verificar específicamente el proxy Ollama
    if pgrep -f "ollama-proxy.py" > /dev/null 2>&1; then
        log "✅ Proxy Ollama (ollama-proxy.py) está ejecutándose."
    else
        log "ℹ️ El proxy Ollama no se está ejecutando. Asegúrate de iniciarlo con:" >> "$LOG_FILE"
        log '   python3 /home/antonio/.config/opencode/ollama-proxy.py 4000 > /tmp/ollama-proxy.log 2>&1 & disown' >> "$LOG_FILE"
    fi
    
    # 2. Verificar modelos disponibles
    check_models
    
    # 3. Verificar persistencia de datos (memoria)
    check_memory
    
    # 4. Comprobar PWAs en Escritorio
    check_pwafs
    
    # 5. Verificar variables de entorno
    check_env
    
    # Resumen final
    log "=== RESUMEN DE INICIALIZACIÓN ===" >> "$LOG_FILE"
    
    if [ -f "${DATA_DIR}/available_models.txt" ]; then
        local model_count=$(wc -l < "${DATA_DIR}/available_models.txt")
        log "📦 Total de modelos disponibles: $model_count" >> "$LOG_FILE"
    else
        log "⚠️ No se pudo determinar el número de modelos." >> "$LOG_FILE"
    fi
    
    if [ -f "${SCRIPT_DIR}/.env" ]; then
        log "✅ Configuración .env lista." >> "$LOG_FILE"
    fi
    
    echo "" >> "$LOG_FILE"
    log "=== INICIALIZACIÓN COMPLETADA ===" >> "$LOG_FILE"
    
    # Mostrar resumen en consola (últimas líneas del log)
    tail -20 "$LOG_FILE"
}

# Ejecutar inicialización
main

echo ""
echo "✅ Inicialización de OpenCode completada."
echo "📄 Ver detalles en: ${SCRIPT_DIR}/data/init.log"

INITEOF
chmod +x "$DIR_CONFIG/init-opencode.sh"
info "init-opencode.sh creado"

# ═══════════════════════════════════════════════════════════
# PASO 10: tui.json (plugin de voz)
# ═══════════════════════════════════════════════════════════
echo "--- 10/14: Configuración TUI ---"
cat > "$DIR_CONFIG/tui.json" << 'TUIEOF'
{
  "$schema": "https://opencode.ai/tui.json",
  "keybinds": {
    "session_rename": "f8"
  },
  "plugin": [
    "/home/antonio/.config/opencode/opencode-voice-modified"
  ]
}

TUIEOF
info "tui.json creado"

# ─── Script para cargar LM Studio con 131K contexto ─────
cat > "$DIR_CONFIG/start-lmstudio.sh" << 'LMSEOF'
#!/usr/bin/env bash
# Inicia LM Studio con el modelo qwen3.5-9b y 131K de contexto
# Ejecutar tras cada reinicio del sistema

set -euo pipefail

LMSTUDIO_BIN="/home/antonio/.lmstudio/bin/lms"
MODELO="qwen/qwen3.5-9b"
CONTEXTO=131072
PUERTO=1234

# Arrancar servidor si no está
if ! $LMSTUDIO_BIN status 2>/dev/null | grep -q "ON"; then
    echo "Arrancando servidor LM Studio..."
    $LMSTUDIO_BIN server start
    sleep 2
fi

# Descargar modelo actual y cargar con contexto grande
$LMSTUDIO_BIN unload "$MODELO" 2>/dev/null
echo "Cargando $MODELO con contexto $CONTEXTO..."
$LMSTUDIO_BIN load "$MODELO" -c $CONTEXTO -y

echo "✅ LM Studio listo en puerto $PUERTO con $CONTEXTO de contexto"

LMSEOF
chmod +x "$DIR_CONFIG/start-lmstudio.sh"
info "start-lmstudio.sh creado (contexto 131K)"

# ─── Configurar LM Studio con 131K de contexto ─────────
echo "--- Configurando LM Studio (contexto 131K) ---"
mkdir -p "$HOME/.lmstudio"
if [ -f "$DIR_CONFIG/../settings.lmstudio.json" ]; then
    cp "$DIR_CONFIG/../settings.lmstudio.json" "$HOME/.lmstudio/settings.json"
    info "settings.json de LM Studio restaurado (contexto 131K)"
elif [ -f "/tmp/opencode-restore/settings.lmstudio.json" ]; then
    cp "/tmp/opencode-restore/settings.lmstudio.json" "$HOME/.lmstudio/settings.json"
    info "settings.json restaurado desde backup"
else
    # Modificar settings.json si existe para poner contexto 131K
    if [ -f "$HOME/.lmstudio/settings.json" ]; then
        python3 -c "
import json
with open('$HOME/.lmstudio/settings.json') as f:
    s = json.load(f)
s['defaultContextLength'] = {'type': 'custom', 'value': 131072}
with open('$HOME/.lmstudio/settings.json', 'w') as f:
    json.dump(s, f, indent=2)
" 2>/dev/null && info "LM Studio configurado con 131K de contexto" || warn "No se pudo configurar LM Studio"
    fi
fi

# ═══════════════════════════════════════════════════════════
# PASO 11: Variables de entorno (.env)
# ═══════════════════════════════════════════════════════════
echo "--- 11/14: Variables de entorno ---"
cat > "$DIR_CONFIG/.env" << 'ENVEOF'
# Configuración de variables de entorno para OpenCode
# Fecha: 26/07/2026
# Usuario: Antonio

# =============================================================================
# --- Ollama ---
# =============================================================================
OLLAMA_API_KEY=ollama
OLLAMA_PROXY_PORT=4000

# =============================================================================
# --- Context7 (API de documentación) ---
# =============================================================================
MCP_CONTEXT7_URL=https://mcp.context7.com/mcp

# =============================================================================
# --- Chrome Debug (PWAs) ---
# =============================================================================
CHROME_DEBUG_PROFILE=/tmp/chrome-debug-profile
REMOTE_DEBUGGING_PORT=9222

# =============================================================================
# --- Navegación web / Fetch ---
# =============================================================================
USER_AGENT="Mozilla/5.0 (compatible; OpenCode-Bot)"
MAX_SEARCH_RESULTS=8
TIMEOUT_SECONDS=120

# =============================================================================
# --- Persistencia de datos (Memoria) ---
# =============================================================================
MEMORY_DATA_DIR=/home/antonio/.config/opencode/data/memory
MEMORY_BACKUP_ENABLED=true
MEMORY_BACKUP_PATH=/home/antonio/Config/opencode/backups/mcp-memory-backup-$(date '+%Y-%m-%d_%H%M').json

# =============================================================================
# --- Logging / Auditoría ---
# =============================================================================
LOG_FILE=/home/antonio/.config/opencode/data/init.log
LOG_RETENTION_DAYS=30
AUDIT_ENABLED=true

# =============================================================================
# ⚠️ CREDENCIALES SEGURAS (NO COMENTAR PARA ACTIVAR) ---
# Copia este archivo a .env y edita con valores reales antes de usar
# =============================================================================
# OLLAMA_API_KEY=tu_clave_segura_aqui
# EXTERNAL_SERVICE_API_KEY=tu_api_key_externa_aqui

# =============================================================================
# --- Variables opcionales (desactivadas por defecto) ---
# =============================================================================
ENABLE_METRICS=false
METRICS_EXPORT_PATH=/home/antonio/.config/opencode/data/metrics.json

ENVEOF
chmod 600 "$DIR_CONFIG/.env"
info ".env creado (permisos 600)"

# ═══════════════════════════════════════════════════════════
# PASO 12: npm dependencies
# ═══════════════════════════════════════════════════════════
echo "--- 12/14: Dependencias npm ---"
cd "$DIR_CONFIG"
if [ ! -f package.json ]; then
    cat > package.json << 'PKGEOF'
{
  "dependencies": {
    "@opencode-ai/plugin": "1.17.13",
    "@renjfk/opencode-voice": "^0.6.0"
  }
}
PKGEOF
fi
npm install --no-audit --no-fund 2>/dev/null || npm install
info "Dependencias npm instaladas"

# ═══════════════════════════════════════════════════════════
# PASO 13: Arrancar proxy
# ═══════════════════════════════════════════════════════════
echo "--- 13/14: Arrancando proxy ---"
if pgrep -f "ollama-proxy.py" &>/dev/null; then
    info "Proxy ya corriendo"
else
    python3 "$DIR_CONFIG/ollama-proxy.py" 4000 > "$LOG_PROXY" 2>&1 & disown
    sleep 2
    if pgrep -f "ollama-proxy.py" &>/dev/null; then
        info "Proxy iniciado en puerto 4000"
    else
        warn "Error al iniciar proxy. Log: $LOG_PROXY"
    fi
fi

# ═══════════════════════════════════════════════════════════
# PASO 14: Verificación final
# ═══════════════════════════════════════════════════════════
echo "--- 14/14: Verificación ---"
if curl -sf http://127.0.0.1:4000/v1/models &>/dev/null; then
    info "Proxy responde correctamente"
else
    warn "Proxy no responde aún"
fi

if command -v opencode &>/dev/null; then
    info "OpenCode listo"
fi

# ─── Restaurar .zshrc completo ──────────────────────
echo "--- Restaurando .zshrc ---"
ZSHRC="$HOME/.zshrc"
if [ -f "$DIR_CONFIG/../.zshrc" ]; then
    # Si hay .zshrc en el directorio del script, restaurarlo completo
    if [ -f "$ZSHRC" ]; then
        cp "$ZSHRC" "$ZSHRC.backup-$(date +%Y%m%d-%H%M%S)"
        info "Backup del .zshrc actual guardado"
    fi
    cp "$DIR_CONFIG/../.zshrc" "$ZSHRC"
    info ".zshrc restaurado completo"
elif [ -f "/tmp/opencode-restore/.zshrc" ]; then
    if [ -f "$ZSHRC" ]; then
        cp "$ZSHRC" "$ZSHRC.backup-$(date +%Y%m%d-%H%M%S)"
    fi
    cp "/tmp/opencode-restore/.zshrc" "$ZSHRC"
    info ".zshrc restaurado desde backup temporal"
else
    info "No hay .zshrc backup, añadiendo solo partes de OpenCode..."
    if ! grep -q "function ocv" "$ZSHRC" 2>/dev/null; then
        echo "" >> "$ZSHRC"
        echo "# OCV - OpenCode con voz" >> "$ZSHRC"
        echo 'function ocv() {' >> "$ZSHRC"
        echo '    script -q -f -c "opencode $*" /dev/null 2>&1' >> "$ZSHRC"
        echo '}' >> "$ZSHRC"
    fi
    if ! grep -q "alias opencode-local" "$ZSHRC" 2>/dev/null; then
        cat >> "$ZSHRC" << 'ZSHEOF'

# Alias para OpenCode con perfiles local/cloud
alias opencode-local="bash ~/.config/opencode/switch-mcp-profile.sh local && opencode"
alias opencode-cloud="bash ~/.config/opencode/switch-mcp-profile.sh cloud && opencode"
alias ocv-local="bash ~/.config/opencode/switch-mcp-profile.sh local && ocv"
alias ocv-cloud="bash ~/.config/opencode/switch-mcp-profile.sh cloud && ocv"
ZSHEOF
    fi
    if ! grep -q '\.local/bin' "$ZSHRC" 2>/dev/null; then
        echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$ZSHRC"
    fi
    info "Partes de OpenCode añadidas al .zshrc"
fi

echo ""
echo "=============================================="
echo -e "${VERDE}  INSTALACIÓN COMPLETA${NC}"
echo "=============================================="
echo ""
echo "Para iniciar OpenCode con voz:"
echo "  opencode"
echo ""
echo "O con el wrapper ocv:"
echo "  ocv"
echo ""
echo "Atajos de voz:"
echo "  Ctrl+R  → Grabar/Transcribir"
echo "  Espacio+V → Toggle TTS"
echo "  Espacio+S → Leer respuesta"
echo "  Escape  → Parar reproducción"
echo ""
echo "Configuración instalada en: $DIR_CONFIG"
echo "Proxy:     http://127.0.0.1:4000"
echo "Modelos:   ${#MODELOS[@]} descargados"
echo ""

# Si hay un backup-local, regenerarlo
if [ -f "$HOME/Config/opencode/backup-opencode.sh" ]; then
    bash "$HOME/Config/opencode/backup-opencode.sh" 2>/dev/null || true
fi
