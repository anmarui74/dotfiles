#!/usr/bin/env bash
# restore.sh - Restaura la config de MiMoCode desde este tarball
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[+] Restaurando config en ~/.config/mimocode ..."
tar -xzf "$HERE/config.tar.gz" -C "$HOME/.config"

if [ -f "$HERE/credenciales/auth.json" ]; then
  echo "[+] Restaurando credenciales en ~/.local/share/mimocode/auth.json ..."
  mkdir -p "$HOME/.local/share/mimocode"
  install -m 600 "$HERE/credenciales/auth.json" "$HOME/.local/share/mimocode/auth.json"
fi

if [ -f "$HERE/setup.tar.gz" ] && [ -s "$HERE/setup.tar.gz" ]; then
  echo "[+] Restaurando instalador en ~/Config/mimocode/sesion-mimocode ..."
  mkdir -p "$HOME/Config/mimocode/sesion-mimocode"
  tar -xzf "$HERE/setup.tar.gz" -C "$HOME/Config/mimocode/sesion-mimocode"
fi

if [ -f "$HERE/scripts/backup-mimocode.sh" ]; then
  echo "[+] Restaurando backup-mimocode.sh ..."
  cp "$HERE/scripts/backup-mimocode.sh" "$HOME/Config/mimocode/backup-mimocode.sh"
  chmod +x "$HOME/Config/mimocode/backup-mimocode.sh"
fi

echo "[+] Restauracion completada."
echo "    Reinstalacion desde cero: bash ~/Config/mimocode/sesion-mimocode/setup-mimocode-completo.sh"
echo "    Si un plugin necesita dependencias: cd ~/.config/mimocode && npm install"
